import { Component, type OnInit } from "@angular/core"
import type { BankingService } from "../services/banking.service"
import type { StatisticsService } from "../services/statistics.service"

@Component({
  selector: "app-about",
  templateUrl: "./about.component.html",
  styleUrls: ["./about.component.css"],
})
export class AboutComponent implements OnInit {
  statistics = {
    happyCustomers: 50000,
    loansDispersed: 5000,
    yearsOfExcellence: 15,
    totalLoanAmount: 0,
  }

  features = [
    {
      icon: "shield-alt",
      title: "Secure & Reliable",
      description: "Bank-grade security with 256-bit SSL encryption to protect your data",
    },
    {
      icon: "clock",
      title: "Quick Processing",
      description: "Get loan approval in just 24 hours with our streamlined digital process",
    },
    {
      icon: "percentage",
      title: "Competitive Rates",
      description: "Starting from 8.5% per annum with flexible repayment options",
    },
    {
      icon: "headset",
      title: "24/7 Support",
      description: "Round-the-clock customer support to assist you at every step",
    },
  ]

  values = [
    { title: "Transparency", description: "Clear terms and no hidden charges" },
    { title: "Innovation", description: "Cutting-edge technology for seamless experience" },
    { title: "Trust", description: "Building long-term relationships with our customers" },
    { title: "Excellence", description: "Committed to delivering exceptional service" },
  ]

  constructor(
    private bankingService: BankingService,
    private statisticsService: StatisticsService,
  ) {}

  ngOnInit(): void {
    this.loadDynamicStatistics()
    this.subscribeToUpdates()
  }

  loadDynamicStatistics(): void {
    // Load current statistics from service
    this.statisticsService.getStatistics().subscribe((stats) => {
      this.statistics = {
        ...this.statistics,
        ...stats,
      }
    })
  }

  subscribeToUpdates(): void {
    // Subscribe to real-time updates
    this.statisticsService.statisticsUpdated$.subscribe((updatedStats) => {
      this.statistics = {
        ...this.statistics,
        ...updatedStats,
      }
    })

    // Subscribe to new loan applications
    this.bankingService.loanApplicationSubmitted$.subscribe((loanData) => {
      this.updateStatisticsOnLoanSubmission(loanData)
    })

    // Subscribe to new user logins
    this.bankingService.userLoggedIn$.subscribe((userData) => {
      this.updateStatisticsOnLogin(userData)
    })
  }

  updateStatisticsOnLoanSubmission(loanData: any): void {
    this.statistics.loansDispersed += 1
    this.statistics.totalLoanAmount += Number.parseFloat(loanData.loanAmount || 0)

    // Update the loans dispersed amount in crores
    const totalAmountInCrores = Math.floor(this.statistics.totalLoanAmount / 10000000)
    if (totalAmountInCrores > 5000) {
      this.statistics.loansDispersed = totalAmountInCrores
    }

    // Save updated statistics
    this.statisticsService.updateStatistics(this.statistics)
  }

  updateStatisticsOnLogin(userData: any): void {
    // Increment happy customers count for new users
    if (userData.isNewUser) {
      this.statistics.happyCustomers += 1
      this.statisticsService.updateStatistics(this.statistics)
    }
  }

  formatCurrency(amount: number): string {
    if (amount >= 10000000) {
      return `₹${Math.floor(amount / 10000000)}Cr+`
    } else if (amount >= 100000) {
      return `₹${Math.floor(amount / 100000)}L+`
    }
    return `₹${amount.toLocaleString()}`
  }

  formatNumber(num: number): string {
    if (num >= 100000) {
      return `${Math.floor(num / 1000)}K+`
    }
    return `${num.toLocaleString()}+`
  }
}
