import { NgModule } from "@angular/core"
import { BrowserModule } from "@angular/platform-browser"
import { RouterModule } from "@angular/router"

import { AppComponent } from "./app.component"
import { AboutComponent } from "./about/about.component"
import { BankingService } from "./services/banking.service"
import { StatisticsService } from "./services/statistics.service"

@NgModule({
  declarations: [AppComponent, AboutComponent],
  imports: [
    BrowserModule,
    RouterModule.forRoot([
      { path: "about", component: AboutComponent },
      { path: "", redirectTo: "/about", pathMatch: "full" },
    ]),
  ],
  providers: [BankingService, StatisticsService],
  bootstrap: [AppComponent],
})
export class AppModule {}
