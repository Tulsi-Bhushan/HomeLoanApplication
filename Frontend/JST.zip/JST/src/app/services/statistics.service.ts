import { Injectable } from "@angular/core"
import { BehaviorSubject, type Observable } from "rxjs"

export interface Statistics {
  happyCustomers: number
  loansDispersed: number
  yearsOfExcellence: number
  totalLoanAmount: number
}

@Injectable({
  providedIn: "root",
})
export class StatisticsService {
  private statisticsSubject = new BehaviorSubject<Statistics>({
    happyCustomers: 50000,
    loansDispersed: 5000,
    yearsOfExcellence: 15,
    totalLoanAmount: 50000000000, // 5000 Cr in rupees
  })

  public statisticsUpdated$ = this.statisticsSubject.asObservable()

  constructor() {
    this.loadStatisticsFromStorage()
  }

  getStatistics(): Observable<Statistics> {
    return this.statisticsUpdated$
  }

  updateStatistics(newStats: Partial<Statistics>): void {
    const currentStats = this.statisticsSubject.value
    const updatedStats = { ...currentStats, ...newStats }

    this.statisticsSubject.next(updatedStats)
    this.saveStatisticsToStorage(updatedStats)
  }

  incrementLoanCount(loanAmount: number): void {
    const currentStats = this.statisticsSubject.value
    const updatedStats = {
      ...currentStats,
      loansDispersed: currentStats.loansDispersed + 1,
      totalLoanAmount: currentStats.totalLoanAmount + loanAmount,
    }

    this.updateStatistics(updatedStats)
  }

  incrementCustomerCount(): void {
    const currentStats = this.statisticsSubject.value
    this.updateStatistics({
      happyCustomers: currentStats.happyCustomers + 1,
    })
  }

  private loadStatisticsFromStorage(): void {
    const stored = localStorage.getItem("jst-bank-statistics")
    if (stored) {
      try {
        const parsedStats = JSON.parse(stored)
        this.statisticsSubject.next(parsedStats)
      } catch (error) {
        console.error("Error loading statistics from storage:", error)
      }
    }
  }

  private saveStatisticsToStorage(stats: Statistics): void {
    try {
      localStorage.setItem("jst-bank-statistics", JSON.stringify(stats))
    } catch (error) {
      console.error("Error saving statistics to storage:", error)
    }
  }
}
