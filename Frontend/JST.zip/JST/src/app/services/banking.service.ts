import { Injectable } from "@angular/core"
import { Subject } from "rxjs"

@Injectable({
  providedIn: "root",
})
export class BankingService {
  private loanApplicationSubject = new Subject<any>()
  private userLoginSubject = new Subject<any>()

  public loanApplicationSubmitted$ = this.loanApplicationSubject.asObservable()
  public userLoggedIn$ = this.userLoginSubject.asObservable()

  constructor() {}

  // Call this method when a loan application is submitted
  notifyLoanApplicationSubmitted(loanData: any): void {
    this.loanApplicationSubject.next(loanData)
  }

  // Call this method when a user logs in
  notifyUserLogin(userData: any): void {
    this.userLoginSubject.next(userData)
  }

  // Integration method for your existing loan submission
  submitLoanApplication(applicationData: any): Promise<any> {
    return new Promise((resolve, reject) => {
      try {
        // Your existing loan submission logic here

        // After successful submission, notify the statistics service
        this.notifyLoanApplicationSubmitted({
          loanAmount: applicationData.loanAmount,
          applicationId: applicationData.applicationId,
          timestamp: new Date(),
        })

        resolve({
          success: true,
          applicationId: applicationData.applicationId,
        })
      } catch (error) {
        reject(error)
      }
    })
  }

  // Integration method for your existing login
  loginUser(credentials: any): Promise<any> {
    return new Promise((resolve, reject) => {
      try {
        // Your existing login logic here

        // After successful login, notify the statistics service
        this.notifyUserLogin({
          userId: credentials.userId,
          isNewUser: credentials.isNewUser || false,
          timestamp: new Date(),
        })

        resolve({
          success: true,
          user: credentials,
        })
      } catch (error) {
        reject(error)
      }
    })
  }
}
