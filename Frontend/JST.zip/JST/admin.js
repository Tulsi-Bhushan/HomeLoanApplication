// Admin Global Variables
let allApplications = []
let currentViewedApplication = null
let isEditMode = false

// DOM Elements
const adminProfileDropdown = document.getElementById("admin-profile-dropdown")
const adminMobileMenu = document.getElementById("admin-mobile-menu")
const notificationToast = document.getElementById("notification-toast")

// Initialize Admin App
document.addEventListener("DOMContentLoaded", () => {
  // Check if admin is logged in, otherwise redirect
  if (localStorage.getItem("adminLoggedIn") !== "true") {
    window.location.href = "index.html"
    return
  }

  loadApplications()
  renderDashboardSummary()
  renderApplications()

  document.getElementById("admin-name").textContent = "Admin User"
  document.getElementById("admin-email").textContent = "admin@jstbank.com"
  document.getElementById("dropdown-admin-name").textContent = "Admin User"
  document.getElementById("dropdown-admin-email").textContent = "admin@jstbank.com"

  document.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault()
      const sectionId = e.target.getAttribute("onclick").match(/'([^']+)'/)[1]
      showAdminSection(sectionId)
    })
  })


  
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".user-profile")) {
      closeAdminProfileMenu()
    }
  })

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      closeViewApplicationModal()
    }
  })

  loadSettings() // Load admin settings on startup
})

// Admin Navigation Functions
function showAdminSection(sectionName) {
  document.querySelectorAll(".section").forEach((section) => {
    section.classList.remove("active")
  })
  document.getElementById(`${sectionName}-section`).classList.add("active")

  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.remove("active")
  })
  document.querySelector(`.nav-link[onclick*="showAdminSection('${sectionName}')"]`).classList.add("active")

  const adminMobileMenu = document.getElementById("admin-mobile-menu")
  if (adminMobileMenu) adminMobileMenu.classList.remove("show")

  if (sectionName === "applications") {
    renderApplications()
  } else if (sectionName === "dashboard") {
    renderDashboardSummary()
  } else if (sectionName === "settings") {
    loadSettings() // Ensure settings are loaded when navigating to settings page
  }
}

function toggleAdminProfileMenu() {
  const userProfile = document.querySelector(".user-profile")
  const dropdown = document.getElementById("admin-profile-dropdown")
  userProfile.classList.toggle("active")
  dropdown.classList.toggle("show")
}

function closeAdminProfileMenu() {
  const userProfile = document.querySelector(".user-profile")
  const dropdown = document.getElementById("admin-profile-dropdown")
  if (userProfile) userProfile.classList.remove("active")
  if (dropdown) dropdown.classList.remove("show")
}

function toggleAdminMobileMenu() {
  adminMobileMenu.classList.toggle("show")
}

function adminLogout() {
  localStorage.removeItem("adminLoggedIn")
  window.location.href = "index.html"
}

// Data Management
function loadApplications() {
  allApplications = JSON.parse(localStorage.getItem("allApplications") || "[]")
}

function saveApplications() {
  localStorage.setItem("allApplications", JSON.stringify(allApplications))
}

// Dashboard Summary
function renderDashboardSummary() {
  const total = allApplications.length
  const approved = allApplications.filter((app) => app.status === "Approved").length
  const pending = allApplications.filter((app) => app.status === "Under Consideration").length
  const rejected = allApplications.filter((app) => app.status === "Rejected").length

  document.getElementById("total-applications").textContent = total
  document.getElementById("approved-applications").textContent = approved
  document.getElementById("pending-applications").textContent = pending
  document.getElementById("rejected-applications").textContent = rejected

  renderRecentApplications()
}

function renderRecentApplications() {
  const recentTableBody = document.getElementById("recent-applications-table-body")
  recentTableBody.innerHTML = ""

  const recentApps = allApplications
    .slice()
    .sort((a, b) => new Date(b.submissionDate) - new Date(a.submissionDate))
    .slice(0, 5) // Get last 5 applications, sorted by date

  if (recentApps.length === 0) {
    recentTableBody.innerHTML = '<tr><td colspan="6" class="text-center">No recent applications.</td></tr>'
    return
  }

  recentApps.forEach((app) => {
    const row = recentTableBody.insertRow()
    row.innerHTML = `
            <td>${app.applicationNumber}</td>
            <td>${app.applicantName}</td>
            <td>${formatCurrency(app.loanAmount)}</td>
            <td><span class="status-badge ${app.status.toLowerCase().replace(/\s/g, "-")}">${app.status}</span></td>
            <td>${new Date(app.submissionDate).toLocaleDateString("en-IN")}</td>
            <td class="actions-cell">
                <button class="btn btn-sm btn-info" onclick="viewApplication('${app.applicationNumber}')">View</button>
                <button class="btn btn-sm btn-success" onclick="updateApplicationStatus('${app.applicationNumber}', 'Approved')">Approve</button>
                <button class="btn btn-sm btn-danger" onclick="updateApplicationStatus('${app.applicationNumber}', 'Rejected')">Reject</button>
            </td>
        `
  })
}

// Applications List
function renderApplications() {
  const allTableBody = document.getElementById("all-applications-table-body")
  allTableBody.innerHTML = ""

  const filterStatus = document.getElementById("filter-status").value
  const searchTerm = document.getElementById("search-app").value.toLowerCase()

  const filteredApps = allApplications
    .filter((app) => {
      const matchesStatus = filterStatus === "all" || app.status === filterStatus
      const matchesSearch =
        app.applicationNumber.toLowerCase().includes(searchTerm) || app.applicantName.toLowerCase().includes(searchTerm)
      return matchesStatus && matchesSearch
    })
    .sort((a, b) => new Date(b.submissionDate) - new Date(a.submissionDate))

  if (filteredApps.length === 0) {
    allTableBody.innerHTML =
      '<tr><td colspan="8" class="text-center">No applications found matching your criteria.</td></tr>'
    return
  }

  filteredApps.forEach((app) => {
    const row = allTableBody.insertRow()
    row.innerHTML = `
            <td>${app.applicationNumber}</td>
            <td>${app.applicantName}</td>
            <td>${app.applicantEmail}</td>
            <td>${formatCurrency(app.loanAmount)}</td>
            <td>${app.loanTenure} Years</td>
            <td><span class="status-badge ${app.status.toLowerCase().replace(/\s/g, "-")}">${app.status}</span></td>
            <td>${new Date(app.submissionDate).toLocaleDateString("en-IN")}</td>
            <td class="actions-cell">
                <button class="btn btn-sm btn-info" onclick="viewApplication('${app.applicationNumber}')">View</button>
                <button class="btn btn-sm btn-success" onclick="updateApplicationStatus('${app.applicationNumber}', 'Approved')">Approve</button>
                <button class="btn btn-sm btn-danger" onclick="updateApplicationStatus('${app.applicationNumber}', 'Rejected')">Reject</button>
            </td>
        `
  })
}

// Application Actions
function viewApplication(appNumber) {
  currentViewedApplication = allApplications.find((app) => app.applicationNumber === appNumber)
  if (!currentViewedApplication) {
    showNotification("Application not found.", "error")
    return
  }

  const detailsContent = document.getElementById("application-details-content")
  detailsContent.innerHTML = `
        <h4>Application Summary</h4>
        <div class="detail-group">
            <div class="detail-item"><span>App ID:</span> <span id="modal-app-id">${currentViewedApplication.applicationNumber}</span></div>
            <div class="detail-item"><span>Status:</span> <span id="modal-app-status" class="status-badge ${currentViewedApplication.status.toLowerCase().replace(/\s/g, "-")}">${currentViewedApplication.status}</span></div>
            <div class="detail-item"><span>Applied On:</span> <span>${new Date(currentViewedApplication.submissionDate).toLocaleDateString("en-IN")}</span></div>
            <div class="detail-item"><span>Applicant Name:</span> <span>${currentViewedApplication.applicantName}</span></div>
            <div class="detail-item"><span>Applicant Email:</span> <span>${currentViewedApplication.applicantEmail}</span></div>
            <div class="detail-item"><span>Loan Type:</span> <span>${currentViewedApplication.loanType || "Home Loan"}</span></div>
            <div class="detail-item"><span>Loan Amount:</span> <span id="modal-loan-amount-display">${formatCurrency(currentViewedApplication.loanAmount)}</span></div>
            <div class="detail-item"><span>Loan Tenure:</span> <span id="modal-loan-tenure-display">${currentViewedApplication.loanTenure} Years</span></div>
        </div>

        <h4>Income Details</h4>
        <div class="detail-group">
            <div class="detail-item"><span>Employment Type:</span> <span>${currentViewedApplication.data.step1.employmentType || "N/A"}</span></div>
            <div class="detail-item"><span>Monthly Income:</span> <span>${formatCurrency(currentViewedApplication.data.step1.monthlyIncome) || "N/A"}</span></div>
            <div class="detail-item"><span>Employer Name:</span> <span>${currentViewedApplication.data.step1.employerName || "N/A"}</span></div>
            <div class="detail-item"><span>Work Experience:</span> <span>${currentViewedApplication.data.step1.workExperience ? `${currentViewedApplication.data.step1.workExperience} Years` : "N/A"}</span></div>
            <div class="detail-item"><span>Organization Type:</span> <span>${currentViewedApplication.data.step1.organizationType || "N/A"}</span></div>
            <div class="detail-item"><span>Retirement Age:</span> <span>${currentViewedApplication.data.step1.retirementAge || "N/A"}</span></div>
        </div>

        <h4>Personal Details</h4>
        <div class="detail-group">
            <div class="detail-item"><span>First Name:</span> <span>${currentViewedApplication.data.step3.firstName || "N/A"}</span></div>
            <div class="detail-item"><span>Last Name:</span> <span>${currentViewedApplication.data.step3.lastName || "N/A"}</span></div>
            <div class="detail-item"><span>Phone:</span> <span>${currentViewedApplication.data.step3.phoneNumber || "N/A"}</span></div>
            <div class="detail-item"><span>DOB:</span> <span>${currentViewedApplication.data.step3.dateOfBirth || "N/A"}</span></div>
            <div class="detail-item"><span>Gender:</span> <span>${currentViewedApplication.data.step3.gender || "N/A"}</span></div>
            <div class="detail-item"><span>Marital Status:</span> <span>${currentViewedApplication.data.step3.maritalStatus || "N/A"}</span></div>
            <div class="detail-item"><span>Nationality:</span> <span>${currentViewedApplication.data.step3.nationality || "N/A"}</span></div>
            <div class="detail-item"><span>PAN:</span> <span>${currentViewedApplication.data.step3.panNumber || "N/A"}</span></div>
            <div class="detail-item"><span>Aadhar:</span> <span>${currentViewedApplication.data.step3.aadharNumber || "N/A"}</span></div>
        </div>
        <p><strong>Address:</strong> ${currentViewedApplication.data.step3.addressLine1 || ""}, ${currentViewedApplication.data.step3.addressLine2 || ""}, ${currentViewedApplication.data.step3.city || ""}, ${currentViewedApplication.data.step3.state || ""} - ${currentViewedApplication.data.step3.pincode || ""}</p>
    `
  isEditMode = false // Reset edit mode
  updateModalButtons()
  document.getElementById("view-application-modal").classList.add("show")
  document.body.style.overflow = "hidden" // Prevent scrolling behind modal
}

function closeViewApplicationModal() {
  document.getElementById("view-application-modal").classList.remove("show")
  document.body.style.overflow = "auto" // Restore scrolling
  currentViewedApplication = null
  isEditMode = false
}

function toggleEditMode() {
  isEditMode = !isEditMode
  const loanAmountDisplay = document.getElementById("modal-loan-amount-display")
  const loanTenureDisplay = document.getElementById("modal-loan-tenure-display")
  const editBtn = document.getElementById("modal-edit-btn")

  if (isEditMode) {
    // Replace spans with input fields
    loanAmountDisplay.innerHTML = `<input type="number" id="edit-loan-amount" value="${currentViewedApplication.loanAmount}" class="form-input" />`
    loanTenureDisplay.innerHTML = `<input type="number" id="edit-loan-tenure" value="${currentViewedApplication.loanTenure}" class="form-input" />`
    editBtn.innerHTML = `<i class="fas fa-save"></i> Save`
    editBtn.classList.remove("btn-primary")
    editBtn.classList.add("btn-success")
  } else {
    // Save changes and revert to spans
    const newLoanAmount = Number.parseFloat(document.getElementById("edit-loan-amount").value)
    const newLoanTenure = Number.parseFloat(document.getElementById("edit-loan-tenure").value)

    if (!isNaN(newLoanAmount) && newLoanAmount > 0 && !isNaN(newLoanTenure) && newLoanTenure > 0) {
      currentViewedApplication.loanAmount = newLoanAmount
      currentViewedApplication.loanTenure = newLoanTenure
      currentViewedApplication.data.step2.loanAmountRequired = newLoanAmount.toString()
      currentViewedApplication.data.step2.loanTenure = newLoanTenure.toString()
      saveApplications()
      showNotification("Loan details updated successfully!", "success")
      renderApplications() // Re-render tables to reflect changes
      renderDashboardSummary()
    } else {
      showNotification("Invalid loan amount or tenure. Please enter valid numbers.", "error")
    }

    loanAmountDisplay.innerHTML = formatCurrency(currentViewedApplication.loanAmount)
    loanTenureDisplay.innerHTML = `${currentViewedApplication.loanTenure} Years`
    editBtn.innerHTML = `<i class="fas fa-edit"></i> Edit`
    editBtn.classList.remove("btn-success")
    editBtn.classList.add("btn-primary")
  }
}

function updateModalButtons() {
  const approveBtn = document.getElementById("modal-approve-btn")
  const rejectBtn = document.getElementById("modal-reject-btn")
  const editBtn = document.getElementById("modal-edit-btn")
  const sendEmailBtn = document.getElementById("modal-send-email-btn")

  if (currentViewedApplication.status === "Approved" || currentViewedApplication.status === "Rejected") {
    approveBtn.style.display = "none"
    rejectBtn.style.display = "none"
    editBtn.style.display = "none"
  } else {
    approveBtn.style.display = "inline-flex"
    rejectBtn.style.display = "inline-flex"
    editBtn.style.display = "inline-flex"
  }
  sendEmailBtn.style.display = "inline-flex" // Always show send email
}

function updateApplicationStatus(appNumber, newStatus) {
  const appIndex = allApplications.findIndex((app) => app.applicationNumber === appNumber)
  if (appIndex > -1) {
    allApplications[appIndex].status = newStatus
    saveApplications()
    showNotification(`Application ${appNumber} status updated to ${newStatus}.`, "success")
    renderApplications()
    renderDashboardSummary()
  } else {
    showNotification("Application not found.", "error")
  }
}

function updateApplicationStatusFromModal(newStatus) {
  if (currentViewedApplication) {
    updateApplicationStatus(currentViewedApplication.applicationNumber, newStatus)
    closeViewApplicationModal()
  }
}

// function sendEmailToApplicant() {
//   if (currentViewedApplication) {
//     const applicantEmail = currentViewedApplication.applicantEmail
//     const appNumber = currentViewedApplication.applicationNumber
//     const appStatus = currentViewedApplication.status

//     let emailSubject = ""
//     let emailBody = ""

//     if (appStatus === "Approved") {
//       emailSubject = "Congratulations! Your Loan Application is Approved!"
//       emailBody = `Dear ${currentViewedApplication.applicantName},\n\nWe are thrilled to inform you that your Home Loan application (Application ID: ${appNumber}) has been approved!\n\nWe will contact you shortly with the next steps for loan disbursement.\n\nCongratulations on taking a step closer to your dream home!\n\nSincerely,\nJST Bank Team`
//       showNotification(`Simulating email to ${applicantEmail}: Loan Approved!`, "success")
//     } else if (appStatus === "Rejected") {
//       const comment = prompt("Enter a comment for the rejected application (optional):")
//       emailSubject = "Update Regarding Your Loan Application with JST Bank"
//       emailBody = `Dear ${currentViewedApplication.applicantName},\n\nWe regret to inform you that your Home Loan application (Application ID: ${appNumber}) has been rejected at this time.\n\n${comment ? `Reason for rejection: ${comment}\n\n` : ""}We understand this may be disappointing. Please feel free to contact our support team for more details or to discuss other financial solutions.\n\nSincerely,\nJST Bank Team`
//       showNotification(`Simulating email to ${applicantEmail}: Loan Rejected.`, "info")
//     } else {
//       emailSubject = `Update on Your Loan Application (${appNumber})`
//       emailBody = `Dear ${currentViewedApplication.applicantName},\n\nThis is an update regarding your Home Loan application (Application ID: ${appNumber}).\n\nYour current status is: ${appStatus}.\n\nWe will notify you as soon as there is a change in your application status.\n\nSincerely,\nJST Bank Team`
//       showNotification(`Simulating email to ${applicantEmail}: Status Update.`, "info")
//     }

//     console.log("--- Simulating Email Send ---")
//     console.log(`To: ${applicantEmail}`)
//     console.log(`Subject: ${emailSubject}`)
//     console.log(`Body:\n${emailBody}`)
//     console.log("-----------------------------")
//   } else {
//     showNotification("No application selected to send email.", "error")
//   }
// }

// Admin Settings


function sendEmailToApplicant() {
  const emailData = {
    recipient: "wsoham2003@gmail.com", // Replace with dynamic value if needed
    msgBody: "Hey Soham, Thank you for registering with us. Your Loan has been Approved",
    subject: "Loan Approved",
    attachment: "Not Present"
  };

  fetch("http://localhost:8093/sendMail", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(emailData)
  })
  .then(response => {
    if (!response.ok) {
      throw new Error("Email sending failed!");
    }
    return response.text();
  })
  .then(data => {
    alert("✅ Email sent successfully!\n\n" + data);
  })
  .catch(error => {
    console.error("Error sending email:", error);
    alert("❌ Failed to send email. Please check console for details.");
  });
}
function updateApplicationStatusFromModal(status) {
  const name = document.getElementById("applicant-name").textContent.trim() || "Applicant";
  const email = document.getElementById("applicant-email").textContent.trim() || "default@example.com";
  const adminNote = document.getElementById("admin-note").value.trim();

  const subject = `🏦 Loan Application Status: ${status}`;
  let msgBody = `Dear ${name},\n\n`;

  if (status === "Approved") {
    msgBody += `🎉 Congratulations! Your home loan application has been *approved*.\n\n✅ Next Steps:\n- A representative will contact you within 2 working days.\n- Ensure all necessary documents are available for verification.\n\n`;
    if (adminNote) msgBody += `📩 Note from our team:\n${adminNote}\n\n`;
    msgBody += `Thank you for trusting JST Bank.\n\nWarm regards,\nJST Bank Loan Department`;
  } else {
    msgBody += `We regret to inform you that your home loan application has been *rejected*.\n\n`;
    if (adminNote) msgBody += `📩 Reason:\n${adminNote}\n\n`;
    msgBody += `You're welcome to reapply after 3 months or contact us for support.\n\nRegards,\nJST Bank Loan Department`;
  }

  const emailData = {
    recipient: email,
    msgBody: msgBody,
    subject: subject,
    attachment: "Not Present"
  };

  // Disable buttons and show spinner
  toggleLoadingState(true);

  fetch("http://localhost:8093/sendMail", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(emailData)
  })
    .then(response => {
      if (!response.ok) throw new Error("Failed to send email");
      return response.text();
    })
    .then(data => {
      alert(`✅ Email successfully sent to ${email}!\nStatus: ${status}`);
      document.getElementById("admin-note").value = "";
    })
    .catch(error => {
      console.error("Email Error:", error);
      alert("❌ Email failed to send. Check console for details.");
    })
    .finally(() => {
      toggleLoadingState(false);
    });
}

function toggleLoadingState(isLoading) {
  const spinner = document.getElementById("email-loading");
  const approveBtn = document.getElementById("approve-btn");
  const rejectBtn = document.getElementById("reject-btn");
  const editBtn = document.getElementById("edit-btn");

  spinner.style.display = isLoading ? "flex" : "none";
  approveBtn.disabled = rejectBtn.disabled = editBtn.disabled = isLoading;
}

function loadSettings() {
  const settings = JSON.parse(localStorage.getItem("adminSettings") || "{}")
  document.getElementById("default-interest-rate").value = settings.defaultInterestRate || 8.5
  document.getElementById("max-loan-amount").value = settings.maxLoanAmount || 50000000
}

function saveSettings() {
  const defaultInterestRate = Number.parseFloat(document.getElementById("default-interest-rate").value)
  const maxLoanAmount = Number.parseFloat(document.getElementById("max-loan-amount").value)

  if (isNaN(defaultInterestRate) || isNaN(maxLoanAmount) || defaultInterestRate <= 0 || maxLoanAmount <= 0) {
    showNotification("Please enter valid numbers for settings.", "error")
    return
  }

  const settings = {
    defaultInterestRate: defaultInterestRate,
    maxLoanAmount: maxLoanAmount,
  }
  localStorage.setItem("adminSettings", JSON.stringify(settings))
  showNotification("Admin settings saved successfully!", "success")
}

// Utility Functions (copied from script.js for consistency)
function formatCurrency(amount) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount)
}

// Notification Functions (copied from script.js for consistency)
function showNotification(message, type = "info") {
  const toast = document.getElementById("notification-toast")
  if (!toast) return

  const icon = toast.querySelector(".toast-icon i")
  const title = toast.querySelector(".toast-title")
  const text = toast.querySelector(".toast-text")
  const toastIconBg = toast.querySelector(".toast-icon")

  text.textContent = message

  switch (type) {
    case "success":
      title.textContent = "Success!"
      icon.className = "fas fa-check-circle"
      if (toastIconBg) toastIconBg.style.background = "var(--success)"
      break
    case "error":
      title.textContent = "Error!"
      icon.className = "fas fa-exclamation-circle"
      if (toastIconBg) toastIconBg.style.background = "var(--error)"
      break
    case "warning":
      title.textContent = "Warning!"
      icon.className = "fas fa-exclamation-triangle"
      if (toastIconBg) toastIconBg.style.background = "var(--warning)"
      break
    default:
      title.textContent = "Info"
      icon.className = "fas fa-info-circle"
      if (toastIconBg) toastIconBg.style.background = "var(--info)"
  }

  toast.classList.add("show")

  setTimeout(() => {
    closeToast()
  }, 5000)
}

function closeToast() {
  const toast = document.getElementById("notification-toast")
  if (toast) toast.classList.remove("show")
}

console.log("JST Bank Admin Dashboard initialized successfully! 📊")
