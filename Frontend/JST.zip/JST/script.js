// Global Variables
let currentStep = 1
let applicationData = {}
let currentUser = null

// DOM Elements
const loadingScreen = document.getElementById("loading-screen")
const authPage = document.getElementById("auth-page")
const mainApp = document.getElementById("main-app")
const loginForm = document.getElementById("login-form")
const signupForm = document.getElementById("signup-form")
const adminLoginForm = document.getElementById("admin-login-form")
const profileDropdown = document.getElementById("profile-dropdown")
const mobileMenu = document.getElementById("mobile-menu")
const notificationToast = document.getElementById("notification-toast")

// Data for Indian States and Cities
const indianStatesAndCities = {
  "Andhra Pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool"],
  "Arunachal Pradesh": ["Itanagar", "Naharlagun"],
  Assam: ["Guwahati", "Dibrugarh", "Silchar", "Jorhat"],
  Bihar: ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur"],
  Chhattisgarh: ["Raipur", "Bhilai", "Bilaspur", "Korba"],
  Goa: ["Panaji", "Margao", "Vasco da Gama"],
  Gujarat: ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar"],
  Haryana: ["Faridabad", "Gurugram", "Panipat", "Ambala"],
  "Himachal Pradesh": ["Shimla", "Dharamshala", "Mandi"],
  Jharkhand: ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro"],
  Karnataka: ["Bengaluru", "Mysuru", "Hubballi", "Mangaluru", "Belagavi"],
  Kerala: ["Kochi", "Thiruvananthapuram", "Kozhikode", "Thrissur"],
  "Madhya Pradesh": ["Bhopal", "Indore", "Jabalpur", "Gwalior"],
  Maharashtra: ["Mumbai", "Pune", "Nagpur", "Nashik", "Aurangabad"],
  Manipur: ["Imphal"],
  Meghalaya: ["Shillong"],
  Mizoram: ["Aizawl"],
  Nagaland: ["Kohima", "Dimapur"],
  Odisha: ["Bhubaneswar", "Cuttack", "Rourkela"],
  Punjab: ["Chandigarh", "Ludhiana", "Amritsar", "Jalandhar"],
  Rajasthan: ["Jaipur", "Jodhpur", "Udaipur", "Kota"],
  Sikkim: ["Gangtok"],
  "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli"],
  Telangana: ["Hyderabad", "Warangal", "Nizamabad"],
  Tripura: ["Agartala"],
  "Uttar Pradesh": ["Lucknow", "Kanpur", "Varanasi", "Agra", "Meerut"],
  Uttarakhand: ["Dehradun", "Haridwar", "Nainital"],
  "West Bengal": ["Kolkata", "Howrah", "Durgapur", "Asansol"],
  "Andaman and Nicobar Islands": ["Port Blair"],
  Chandigarh: ["Chandigarh"],
  "Dadra and Nagar Haveli and Daman and Diu": ["Daman", "Silvassa"],
  Delhi: ["New Delhi", "Delhi"],
  "Jammu and Kashmir": ["Srinagar", "Jammu"],
  Ladakh: ["Leh", "Kargil"],
  Lakshadweep: ["Kavaratti"],
  Puducherry: ["Puducherry"],
}
function populateStateDropdown() {
  const stateSelect = document.getElementById("state")
  if (!stateSelect) return

  stateSelect.innerHTML = '<option value="">Select State</option>'
  const sortedStates = Object.keys(indianStatesAndCities).sort()
  sortedStates.forEach((state) => {
    const option = document.createElement("option")
    option.value = state
    option.textContent = state
    stateSelect.appendChild(option)
  })
}
function populateCityDropdown() {
  const stateSelect = document.getElementById("state")
  const citySelect = document.getElementById("city")
  const selectedState = stateSelect.value

  citySelect.innerHTML = '<option value="">Select City</option>'
  if (selectedState && indianStatesAndCities[selectedState]) {
    const cities = indianStatesAndCities[selectedState].sort()
    cities.forEach((city) => {
      const option = document.createElement("option")
      option.value = city
      option.textContent = city
      citySelect.appendChild(option)
    })
  }
}

// Sort states alphabetically
const sortedStates = Object.keys(indianStatesAndCities).sort()

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  showLoadingScreen()

  setTimeout(() => {
    hideLoadingScreen()
    initializeApp()
  }, 700)
})

// Loading Screen Functions
function showLoadingScreen() {
  loadingScreen.style.display = "flex"
}

function hideLoadingScreen() {
  loadingScreen.style.opacity = "0"
  setTimeout(() => {
    loadingScreen.style.display = "none"
  }, 500)
}

// Initialize Application
function initializeApp() {
  const savedUser = localStorage.getItem("currentUser")
  if (savedUser) {
    currentUser = JSON.parse(savedUser)
    showMainApp()
  } else {
    showAuthPage()
  }

  initializeEventListeners()
  initializeCalculators()
  loadApplicationData()
  populateStateDropdown()
}

// Event Listeners
function initializeEventListeners() {
  if (loginForm) {
    loginForm.addEventListener("submit", handleLogin)
    setupFormValidation("login-form")
  }

  if (signupForm) {
    signupForm.addEventListener("submit", handleSignup)
    setupFormValidation("signup-form")
  }

  if (adminLoginForm) {
    adminLoginForm.addEventListener("submit", handleAdminLogin)
    setupFormValidation("admin-login-form")
  }

  const incomeForm = document.getElementById("income-form")
  const loanForm = document.getElementById("loan-form")
  const personalForm = document.getElementById("personal-form")
  const documentsForm = document.getElementById("documents-form")

  if (incomeForm) {
    incomeForm.addEventListener("submit", (e) => e.preventDefault())
    setupFormValidation("income-form")
  }
  if (loanForm) {
    loanForm.addEventListener("submit", (e) => e.preventDefault())
    setupFormValidation("loan-form")
  }
  if (personalForm) {
    personalForm.addEventListener("submit", (e) => e.preventDefault())
    setupFormValidation("personal-form")
  }
  if (documentsForm) {
    documentsForm.addEventListener("submit", (e) => e.preventDefault())
    setupFormValidation("documents-form")
  }

  initializeDragAndDrop()

  document.addEventListener("click", (e) => {
    if (!e.target.closest(".user-profile")) {
      closeProfileMenu()
    }
  })

  document.querySelectorAll(".form-input").forEach((input) => {
    input.addEventListener("focus", function () {
      this.classList.add("focused")
    })
    input.addEventListener("blur", function () {
      this.classList.remove("focused")
    })
  })

  const stateDropdown = document.getElementById("state")
  if (stateDropdown) {
    stateDropdown.addEventListener("change", populateCityDropdown)
  }
}

// Authentication Functions
function showLogin() {
  document.getElementById("login-form").style.display = "block"
  document.getElementById("signup-form").style.display = "none"
  document.getElementById("admin-login-form").style.display = "none"
  document.querySelectorAll(".auth-tab").forEach((tab) => tab.classList.remove("active"))
  document.querySelectorAll(".auth-tab")[1].classList.add("active") // Login tab
  resetFormValidation("login-form")
  resetFormValidation("signup-form")
  resetFormValidation("admin-login-form")
}

function showSignup() {
  document.getElementById("login-form").style.display = "none"
  document.getElementById("signup-form").style.display = "block"
  document.getElementById("admin-login-form").style.display = "none"
  document.querySelectorAll(".auth-tab").forEach((tab) => tab.classList.remove("active"))
  document.querySelectorAll(".auth-tab")[0].classList.add("active") // Signup tab
  resetFormValidation("login-form")
  resetFormValidation("signup-form")
  resetFormValidation("admin-login-form")
}

function showAdminLogin() {
  document.getElementById("login-form").style.display = "none"
  document.getElementById("signup-form").style.display = "none"
  document.getElementById("admin-login-form").style.display = "block"
  document.querySelectorAll(".auth-tab").forEach((tab) => tab.classList.remove("active"))
  document.querySelectorAll(".auth-tab")[2].classList.add("active") // Admin tab
  resetFormValidation("login-form")
  resetFormValidation("signup-form")
  resetFormValidation("admin-login-form")
}

function handleLogin(e) {
  e.preventDefault()
  if (!validateForm("login-form")) return

  const email = document.getElementById("login-email").value
  const password = document.getElementById("login-password").value

  const registeredUsers = JSON.parse(localStorage.getItem("registeredUsers") || "[]")
  const foundUser = registeredUsers.find((user) => user.email === email && user.password === password)

  const submitBtn = e.target.querySelector('button[type="submit"]')
  const originalText = submitBtn.innerHTML
  submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing In...'
  submitBtn.disabled = true

  setTimeout(() => {
    if (foundUser) {
      currentUser = foundUser
      localStorage.setItem("currentUser", JSON.stringify(currentUser))
      showNotification("Login successful! Welcome back.", "success")
      showMainApp()
      e.target.reset()
    } else {
      showNotification("Invalid email or password. Please sign up if you don't have an account.", "error")
    }
    submitBtn.innerHTML = originalText
    submitBtn.disabled = false
  }, 1500)
}




// function handleSignup(e) {
//   e.preventDefault()
//   if (!validateForm("signup-form")) return

//   const firstName = document.getElementById("signup-firstname").value
//   const lastName = document.getElementById("signup-lastname").value
//   const email = document.getElementById("signup-email").value
//   const phone = document.getElementById("signup-phone").value
//   const password = document.getElementById("signup-password").value
//   const termsAgree = document.getElementById("terms-agree").checked

//   if (!termsAgree) {
//     showNotification("Please agree to the Terms & Conditions", "error")
//     return
//   }

//   const registeredUsers = JSON.parse(localStorage.getItem("registeredUsers") || "[]")
//   if (registeredUsers.some((user) => user.email === email)) {
//     showNotification("This email is already registered. Please log in.", "error")
//     return
//   }

//   const submitBtn = e.target.querySelector('button[type="submit"]')
//   const originalText = submitBtn.innerHTML
//   submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...'
//   submitBtn.disabled = true

//   setTimeout(() => {
//     const newUser = {
//       id: generateId(),
//       name: `${firstName} ${lastName}`,
//       email: email,
//       phone: phone,
//       password: password, // In a real app, hash this password!
//       registrationTime: new Date().toISOString(),
//       // Store initial income/employment data if available from signup form, or set to null
//       monthlyIncome: null,
//       employmentType: null,
//       organizationType: null,
//       employerName: null,
//       workExperience: null,
//       retirementAge: null,
//       dateOfBirth: null,
//       gender: null,
//       maritalStatus: null,
//       nationality: null,
//       panNumber: null,
//       aadharNumber: null,
//       addressLine1: null,
//       addressLine2: null,
//       city: null,
//       state: null,
//       pincode: null,
//     }

//     registeredUsers.push(newUser)
//     localStorage.setItem("registeredUsers", JSON.stringify(registeredUsers))

//     showNotification("Account created successfully! Please log in.", "success")
//     showLogin() // Switch to login tab after successful signup
//     e.target.reset()
//     submitBtn.innerHTML = originalText
//     submitBtn.disabled = false
//   }, 1500)
// }

// function handleAdminLogin(e) {
//   e.preventDefault()
//   if (!validateForm("admin-login-form")) return

//   const adminEmail = document.getElementById("admin-email").value
//   const adminPassword = document.getElementById("admin-password").value

//   const ADMIN_USER = "admin@jstbank.com"
//   const ADMIN_PASS = "admin123"

//   const submitBtn = e.target.querySelector('button[type="submit"]')
//   const originalText = submitBtn.innerHTML
//   submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging In...'
//   submitBtn.disabled = true

//   setTimeout(() => {
//     if (adminEmail === ADMIN_USER && adminPassword === ADMIN_PASS) {
//       localStorage.setItem("adminLoggedIn", "true")
//       showNotification("Admin login successful! Redirecting...", "success")
//       window.location.href = "admin.html"
//     } else {
//       showNotification("Invalid admin credentials.", "error")
//       submitBtn.innerHTML = originalText
//       submitBtn.disabled = false
//     }
//   }, 1000)
// }

// async function handleSignup(e) {
//   e.preventDefault();
//   if (!validateForm("signup-form")) return;
//   const firstName = document.getElementById("signup-firstname").value;
//   const lastName = document.getElementById("signup-lastname").value;
//   const email = document.getElementById("signup-email").value;
//   const phone = document.getElementById("signup-phone").value;
//   const password = document.getElementById("signup-password").value;
//   const termsAgree = document.getElementById("terms-agree").checked;
//   if (!termsAgree) {
//     showNotification("Please agree to the Terms & Conditions", "error");
//     return;
//   }
//   const userPayload = {
//     firstName,
//     lastName,
//     email,
//     phone,
//     password,
//     userType: "Customer" // or "Admin" based on form input or default
//   };
//   const submitBtn = e.target.querySelector('button[type="submit"]');
//   const originalText = submitBtn.innerHTML;
//   submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
//   submitBtn.disabled = true;
//   try {
//     const response = await fetch("http://localhost:8091/user/save", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json"
//       },
//       body: JSON.stringify(userPayload)
//     });
//     if (response.ok) {
//       showNotification("Account created successfully! Please log in.", "success");
//       showLogin(); // switch to login form
//       e.target.reset();
//     } else {
//       const error = await response.text();
//       showNotification("Signup failed: " + error, "error");
//     }
//   } catch (error) {
//     console.error("Error during signup:", error);
//     showNotification("Signup failed due to network/server error.", "error");
//   }
//   submitBtn.innerHTML = originalText;
//   submitBtn.disabled = false;
// }

// async function handleAdminLogin(e) {
//   e.preventDefault();
//   if (!validateForm("admin-login-form")) return;
//   const adminEmail = document.getElementById("admin-email").value;
//   const adminPassword = document.getElementById("admin-password").value;
//   const adminPayload = {
//     email: adminEmail,
//     password: adminPassword,
//     role: "ADMIN" // backend should verify role as well
//   };
//   const submitBtn = e.target.querySelector('button[type="submit"]');
//   const originalText = submitBtn.innerHTML;
//   submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging In...';
//   submitBtn.disabled = true;
//   try {
//     const response = await fetch("http://localhost:8072/user/admin-login", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json"
//       },
//       body: JSON.stringify(adminPayload)
//     });
//     if (response.ok) {
//       const result = await response.json();
//       if (result.success) {
//         localStorage.setItem("adminLoggedIn", "true");
//         showNotification("Admin login successful! Redirecting...", "success");
//         window.location.href = "admin.html";
//       } else {
//         showNotification("Invalid admin credentials.", "error");
//       }
//     } else {
//       const errorText = await response.text();
//       showNotification("Login failed: " + errorText, "error");
//     }
//   } catch (error) {
//     console.error("Admin login error:", error);
//     showNotification("Login failed due to server/network issue.", "error");
//   }
//   submitBtn.innerHTML = originalText;
//   submitBtn.disabled = false;
// }



// function handleAdminLogin(e) {
//   e.preventDefault();
//   if (!validateForm("admin-login-form")) return;
//   const adminEmail = document.getElementById("admin-email").value;
//   const adminPassword = document.getElementById("admin-password").value;
//   const submitBtn = e.target.querySelector('button[type="submit"]');
//   const originalText = submitBtn.innerHTML;
//   submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging In...';
//   submitBtn.disabled = true;
//   // Prepare payload
//   const loginData = {
//     email: adminEmail,
//     password: adminPassword
//   };
//   // Send AJAX request to backend
//   fetch("http://localhost:8072/api/admin/login", {
//     method: "POST",
//     headers: {
//       "Content-Type": "application/json"
//     },
//     body: JSON.stringify(loginData)
//   })
//     .then(response => {
//       if (!response.ok) {
//         throw new Error("Invalid credentials");
//       }
//       return response.json();
//     })
//     .then(data => {
//       // Successful admin login
//       localStorage.setItem("adminLoggedIn", "true");
//       showNotification("Admin login successful! Redirecting...", "success");
//       window.location.href = "admin.html";
//     })
//     .catch(error => {
//       showNotification("Invalid admin credentials.", "error");
//       submitBtn.innerHTML = originalText;
//       submitBtn.disabled = false;
//     });
// }





function showAuthPage() {
  authPage.style.display = "flex"
  mainApp.style.display = "none"
  showLogin() // Default to login form
}

function showMainApp() {
  authPage.style.display = "none"
  mainApp.style.display = "block"
  updateUserInfo()
  showSection("home")
}

function showHomePage() {
  const savedUser = localStorage.getItem("currentUser")
  if (savedUser) {
    currentUser = JSON.parse(savedUser)
    showMainApp()
  } else {
    showAuthPage()
  }
}

function updateUserInfo() {
  if (currentUser) {
    document.getElementById("user-name").textContent = currentUser.name || "User"
    document.getElementById("user-email").textContent = currentUser.email || "user@example.com"
    document.getElementById("dropdown-name").textContent = currentUser.name || "User"
    document.getElementById("dropdown-email").textContent = currentUser.email || "user@example.com"

    // Update My Profile section
    document.getElementById("profile-full-name").textContent = currentUser.name || "N/A"
    document.getElementById("profile-email-address").textContent = currentUser.email || "N/A"
    document.getElementById("profile-phone-number").textContent = currentUser.phone || "N/A"
    document.getElementById("profile-monthly-income").textContent = currentUser.monthlyIncome
      ? formatCurrency(currentUser.monthlyIncome)
      : "N/A"
    document.getElementById("profile-employment-type").textContent = currentUser.employmentType || "N/A"
    document.getElementById("profile-organization-type").textContent = currentUser.organizationType || "N/A"
    document.getElementById("profile-employer-name").textContent = currentUser.employerName || "N/A"
    document.getElementById("profile-work-experience").textContent = currentUser.workExperience
      ? `${currentUser.workExperience} Years`
      : "N/A"
    document.getElementById("profile-retirement-age").textContent = currentUser.retirementAge || "N/A"
    document.getElementById("profile-dob").textContent = currentUser.dateOfBirth || "N/A"
    document.getElementById("profile-gender").textContent = currentUser.gender || "N/A"
    document.getElementById("profile-marital-status").textContent = currentUser.maritalStatus || "N/A"
    document.getElementById("profile-nationality").textContent = currentUser.nationality || "N/A"
    document.getElementById("profile-pan").textContent = currentUser.panNumber || "N/A"
    document.getElementById("profile-aadhar").textContent = currentUser.aadharNumber || "N/A"
    document.getElementById("profile-address-line1").textContent = currentUser.addressLine1 || "N/A"
    document.getElementById("profile-address-line2").textContent = currentUser.addressLine2 || "N/A"
    document.getElementById("profile-city").textContent = currentUser.city || "N/A"
    document.getElementById("profile-state").textContent = currentUser.state || "N/A"
    document.getElementById("profile-pincode").textContent = currentUser.pincode || "N/A"
  }
}

function logout() {
  localStorage.removeItem("currentUser")
  currentUser = null
  showNotification("You have been logged out successfully.", "info")
  showAuthPage()
  mobileMenu.classList.remove("show")
}

// Navigation Functions
function showSection(sectionName) {
  document.querySelectorAll(".section").forEach((section) => {
    section.classList.remove("active")
  })

  const targetSection = document.getElementById(`${sectionName}-section`)
  if (targetSection) {
    targetSection.classList.add("active")
    targetSection.classList.add("fade-in")
  }

  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.remove("active")
  })

  const activeLink = document.querySelector(`[onclick="showSection('${sectionName}')"]`)
  if (activeLink) {
    activeLink.classList.add("active")
  }

  mobileMenu.classList.remove("show")

  if (sectionName === "calculator") {
    calculateEMI()
  } else if (sectionName === "tracker") {
    const savedApplication = localStorage.getItem("currentApplication")
    if (savedApplication) {
      const app = JSON.parse(savedApplication)
      document.getElementById("application-number").value = app.applicationNumber || ""
      document.getElementById("mobile-number").value = app.data.step3 ? app.data.step3.phoneNumber : ""
      trackApplication()
    } else {
      document.getElementById("tracking-result").style.display = "none"
    }
  } else if (sectionName === "my-applications") {
    renderMyApplications()
  } else if (sectionName === "profile") {
    updateUserInfo() // Ensure profile data is fresh
  }
}

function toggleProfileMenu() {
  const userProfile = document.querySelector(".user-profile")
  const dropdown = document.getElementById("profile-dropdown")

  userProfile.classList.toggle("active")
  dropdown.classList.toggle("show")
}

function toggleMobileMenu() {
  mobileMenu.classList.toggle("show")
}

// Password Toggle Function
function togglePassword(inputId) {
  const input = document.getElementById(inputId)
  const button = input.nextElementSibling
  const icon = button.querySelector("i")

  if (input.type === "password") {
    input.type = "text"
    icon.classList.remove("fa-eye")
    icon.classList.add("fa-eye-slash")
  } else {
    input.type = "password"
    icon.classList.remove("fa-eye-slash")
    icon.classList.add("fa-eye")
  }
}

// Calculator Functions
function initializeCalculators() {
  updateQuickCalc()
  calculateEMI()
}

function updateQuickCalc() {
  const loanAmount = Number.parseFloat(document.getElementById("quick-loan-amount").value)
  const tenure = 240 // 20 years in months
  const interestRate = 8.5

  document.getElementById("quick-amount-display").textContent = formatCurrency(loanAmount)

  const monthlyRate = interestRate / (12 * 100)
  const emi = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, tenure)) / (Math.pow(1 + monthlyRate, tenure) - 1)

  document.getElementById("quick-emi-display").textContent = formatCurrency(emi)
}

function calculateEMI() {
  const loanAmountSlider = document.getElementById("loan-amount")
  const tenureSlider = document.getElementById("tenure")

  if (!loanAmountSlider || !tenureSlider) return

  const loanAmount = Number.parseFloat(loanAmountSlider.value)
  const tenure = Number.parseFloat(tenureSlider.value)
  const interestRate = 8.5 // Fixed rate

  document.getElementById("loan-amount-input").value = formatCurrency(loanAmount)
  document.getElementById("tenure-input").value = `${tenure} months (${Math.round(tenure / 12)} years)`

  const monthlyRate = interestRate / (12 * 100)
  const emi = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, tenure)) / (Math.pow(1 + monthlyRate, tenure) - 1)

  const totalAmount = emi * tenure
  const totalInterest = totalAmount - loanAmount

  document.getElementById("emi-result").textContent = formatCurrency(emi)
  document.getElementById("total-interest").textContent = formatCurrency(totalInterest)
  document.getElementById("total-amount").textContent = formatCurrency(totalAmount)
  document.getElementById("principal-amount").textContent = formatCurrency(loanAmount)
  document.getElementById("loan-tenure-display").textContent = `${Math.round(tenure / 12)} years`
  document.getElementById("monthly-emi").textContent = formatCurrency(emi)

  document.getElementById("schedule-loan-amount").textContent = formatCurrency(loanAmount)
  document.getElementById("schedule-tenure").textContent = `${Math.round(tenure / 12)} years`
  document.getElementById("schedule-emi").textContent = formatCurrency(emi)
}

function updateSliderFromInput(sliderId, value) {
  const numericValue = Number.parseFloat(value.replace(/[₹,]/g, ""))
  if (!isNaN(numericValue)) {
    document.getElementById(sliderId).value = numericValue
    calculateEMI()
  }
}

function updateTenureFromInput(value) {
  const monthsMatch = value.match(/(\d+)\s*months/)
  if (monthsMatch) {
    const months = Number.parseInt(monthsMatch[1])
    if (!isNaN(months)) {
      document.getElementById("tenure").value = months
      calculateEMI()
      return
    }
  }
  const yearsMatch = value.match(/(\d+)\s*years/)
  if (yearsMatch) {
    const years = Number.parseInt(yearsMatch[1])
    if (!isNaN(years)) {
      document.getElementById("tenure").value = years * 12
      calculateEMI()
      return
    }
  }
}

function showRepaymentSchedule() {
  const modal = document.getElementById("schedule-modal")
  const loanAmount = Number.parseFloat(document.getElementById("loan-amount").value)
  const tenure = Number.parseFloat(document.getElementById("tenure").value)
  const interestRate = 8.5

  generateRepaymentSchedule(loanAmount, tenure, interestRate)

  modal.classList.add("show")
  document.body.style.overflow = "hidden"
}

function closeScheduleModal() {
  const modal = document.getElementById("schedule-modal")
  modal.classList.remove("show")
  document.body.style.overflow = "auto"
}

function generateRepaymentSchedule(loanAmount, tenure, interestRate) {
  const monthlyRate = interestRate / (12 * 100)
  const emi = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, tenure)) / (Math.pow(1 + monthlyRate, tenure) - 1)

  const tableBody = document.getElementById("schedule-table-body")
  tableBody.innerHTML = ""

  let balance = loanAmount

  for (let month = 1; month <= tenure; month++) {
    const interestPayment = balance * monthlyRate
    const principalPayment = emi - interestPayment
    balance -= principalPayment

    const row = document.createElement("tr")
    row.innerHTML = `
          <td>${month}</td>
          <td>${formatCurrency(emi)}</td>
          <td>${formatCurrency(principalPayment)}</td>
          <td>${formatCurrency(interestPayment)}</td>
          <td>${formatCurrency(Math.max(0, balance))}</td>
      `
    tableBody.appendChild(row)
  }
}

// Application Form Functions
// function nextStep(step) {
//   const currentFormId = `step-${currentStep}`
//   if (!validateForm(currentFormId)) {
//     return
//   }

//   saveStepData()

//   document.getElementById(`step-${currentStep}`).classList.remove("active")
//   currentStep = step
//   document.getElementById(`step-${currentStep}`).classList.add("active")
//   updateProgress()
//   window.scrollTo({ top: 0, behavior: "smooth" })
// }


// function prevStep(step) {
//   document.getElementById(`step-${currentStep}`).classList.remove("active")
//   currentStep = step
//   document.getElementById(`step-${currentStep}`).classList.add("active")
//   updateProgress()




//   window.scrollTo({ top: 0, behavior: "smooth" })
// }


function updateStepIndicators() {
  document.querySelectorAll(".step").forEach((stepEl, index) => {
    stepEl.classList.remove("active", "completed");
    if (index + 1 < currentStep) {
      stepEl.classList.add("completed");
    } else if (index + 1 === currentStep) {
      stepEl.classList.add("active");
    }
  });
}

function updateBackground() {
  const colors = {
    1: "#E6F0FF", // Income
    2: "#FFF5E1", // Loan
    3: "#E9FFE8", // Personal
    4: "#FFF0F5"  // Documents
  };
  document.body.style.backgroundColor = colors[currentStep] || "#FFFFFF";
}
function nextStep(step) {
  const currentFormId = `step-${currentStep}`;
  if (!validateForm(currentFormId)) return;

  saveStepData();

  document.getElementById(`step-${currentStep}`).classList.remove("active");
  currentStep = step;
  document.getElementById(`step-${currentStep}`).classList.add("active");

  updateProgress();
  updateStepIndicators();
  updateBackground();

  window.scrollTo({ top: 0, behavior: "smooth" });
}

function prevStep(step) {
  document.getElementById(`step-${currentStep}`).classList.remove("active");
  currentStep = step;
  document.getElementById(`step-${currentStep}`).classList.add("active");

  updateProgress();
  updateStepIndicators();
  updateBackground();

  window.scrollTo({ top: 0, behavior: "smooth" });
}

















function showStep(step) {
  document.querySelectorAll(".application-step").forEach((stepEl) => {
    stepEl.classList.remove("active")
  })

  document.getElementById(`step-${step}`).classList.add("active")

  document.querySelectorAll(".step").forEach((stepEl, index) => {
    stepEl.classList.remove("active", "completed")
    if (index + 1 < step) {
      stepEl.classList.add("completed")
    } else if (index + 1 === step) {
      stepEl.classList.add("active")
    }
  })
}

function updateProgress() {
  const progressFill = document.getElementById("progress-fill")
  const progressPercentage = ((currentStep - 1) / 3) * 100
  progressFill.style.width = `${progressPercentage}%`
}

function saveStepData() {
  const currentStepEl = document.getElementById(`step-${currentStep}`)
  const formData = new FormData(currentStepEl.querySelector("form"))

  const stepData = {}
  for (const [key, value] of formData.entries()) {
    stepData[key] = value
  }

  applicationData[`step${currentStep}`] = stepData

  // Update currentUser with relevant data from application form
  if (currentUser) {
    if (currentStep === 1) {
      currentUser.monthlyIncome = stepData.monthlyIncome ? Number.parseFloat(stepData.monthlyIncome) : null
      currentUser.employmentType = stepData.employmentType || null
      currentUser.organizationType = stepData.organizationType || null
      currentUser.employerName = stepData.employerName || null
      currentUser.workExperience = stepData.workExperience ? Number.parseFloat(stepData.workExperience) : null
      currentUser.retirementAge = stepData.retirementAge ? Number.parseFloat(stepData.retirementAge) : null
    } else if (currentStep === 3) {
      currentUser.name = `${stepData.firstName || ""} ${stepData.lastName || ""}`.trim()
      currentUser.email = stepData.emailAddress || null
      currentUser.phone = stepData.phoneNumber || null
      currentUser.dateOfBirth = stepData.dateOfBirth || null
      currentUser.gender = stepData.gender || null
      currentUser.maritalStatus = stepData.maritalStatus || null
      currentUser.nationality = stepData.nationality || null
      currentUser.panNumber = stepData.panNumber || null
      currentUser.aadharNumber = stepData.aadharNumber || null
      currentUser.addressLine1 = stepData.addressLine1 || null
      currentUser.addressLine2 = stepData.addressLine2 || null
      currentUser.city = stepData.city || null
      currentUser.state = stepData.state || null
      currentUser.pincode = stepData.pincode || null
    }
    localStorage.setItem("currentUser", JSON.stringify(currentUser))
    updateUserInfo() // Update profile display immediately
  }

  localStorage.setItem("applicationData", JSON.stringify(applicationData))
}

function loadApplicationData() {
  const savedData = localStorage.getItem("applicationData")
  if (savedData) {
    applicationData = JSON.parse(savedData)
    populateFormsWithSavedData()
  }
}

function populateFormsWithSavedData() {
  Object.keys(applicationData).forEach((stepKey) => {
    const stepData = applicationData[stepKey]
    Object.keys(stepData).forEach((fieldName) => {
      const field = document.querySelector(`[name="${fieldName}"]`)
      if (field) {
        // Skip file inputs to prevent InvalidStateError
        if (field.type === "file") {
          return
        }

        if (field.tagName === "SELECT" && (field.id === "state" || field.id === "city")) {
          // Handle dropdowns separately
          if (field.id === "state") {
            field.value = stepData[fieldName]
            populateCityDropdown() // Repopulate cities based on loaded state
          }
          if (field.id === "city") {
            field.value = stepData[fieldName]
          }
        } else {
          field.value = stepData[fieldName]
        }
      }
    })
  })
}

function checkEligibility() {
  const monthlyIncome = Number.parseFloat(document.getElementById("monthly-income").value)
  const propertyCost = Number.parseFloat(document.getElementById("property-cost").value)
  const loanTenureYears = Number.parseFloat(document.getElementById("loan-tenure").value)

  if (
    isNaN(monthlyIncome) ||
    isNaN(propertyCost) ||
    isNaN(loanTenureYears) ||
    monthlyIncome <= 0 ||
    propertyCost <= 0 ||
    loanTenureYears <= 0
  ) {
    showNotification("Please fill in valid income, property cost, and loan tenure to check eligibility.", "error")
    document.getElementById("eligibility-result").style.display = "none"
    return
  }

  const maxLoanBasedOnProperty = propertyCost * 0.8
  const maxLoanBasedOnIncome = monthlyIncome * 60
  const maxEligibleAmount = Math.min(maxLoanBasedOnProperty, maxLoanBasedOnIncome)

  const R = 8.5 / (12 * 100)
  const N = loanTenureYears * 12
  const estimatedEmi = (maxEligibleAmount * R * Math.pow(1 + R, N)) / (Math.pow(1 + R, N) - 1)

  document.getElementById("max-eligible-amount").textContent = formatCurrency(maxEligibleAmount)
  document.getElementById("estimated-emi").textContent = formatCurrency(estimatedEmi)
  document.getElementById("eligibility-result").style.display = "grid"

  if (document.getElementById("loan-amount-required").value <= maxEligibleAmount) {
    showNotification("Great! You are eligible for the requested loan amount.", "success")
  } else {
    showNotification("The requested amount exceeds your eligibility. Consider a lower amount.", "warning")
  }
}

function submitApplication() {
  if (!validateForm("documents-form")) {
    showNotification("Please complete all required fields and upload documents.", "error")
    return
  }

  saveStepData()

  const applicationNumber = `JST${new Date().getFullYear()}${String(Math.floor(Math.random() * 100000000)).padStart(8, "0")}`
  const referenceId = `REF${String(Math.floor(Math.random() * 1000000000)).padStart(9, "0")}`

  const application = {
    applicationNumber: applicationNumber,
    referenceId: referenceId,
    userId: currentUser ? currentUser.id : "guest",
    applicantName: applicationData.step3
      ? `${applicationData.step3.firstName} ${applicationData.step3.lastName}`
      : "N/A",
    applicantEmail: applicationData.step3 ? applicationData.step3.emailAddress : "N/A",
    loanAmount: applicationData.step2 ? Number.parseFloat(applicationData.step2.loanAmountRequired) : 0,
    loanTenure: applicationData.step2 ? Number.parseFloat(applicationData.step2.loanTenure) : 0,
    loanType: "Home Loan", // Explicitly set loan type
    submissionDate: new Date().toISOString(),
    status: "Under Consideration",
    data: applicationData,
  }

  const allApplications = JSON.parse(localStorage.getItem("allApplications") || "[]")
  allApplications.push(application)
  localStorage.setItem("allApplications", JSON.stringify(allApplications))

  localStorage.setItem("currentApplication", JSON.stringify(application))

  document.getElementById("generated-app-number").textContent = applicationNumber
  document.getElementById("generated-ref-id").textContent = referenceId
  document.getElementById("success-modal").classList.add("show")

  showNotification(`Application submitted successfully! Your application number is ${applicationNumber}`, "success")

  // Reset application form state
  currentStep = 1
  applicationData = {}
  document.getElementById("income-form").reset()
  document.getElementById("loan-form").reset()
  document.getElementById("personal-form").reset()
  document.getElementById("documents-form").reset()
  resetFormValidation("income-form")
  resetFormValidation("loan-form")
  resetFormValidation("personal-form")
  resetFormValidation("documents-form")
  updateProgress()
  showStep(1)
}

/**********************************submit form for income**************************************************/
async function submitIncomeDetails() {
  // Collect form values
  const employmentType = document.getElementById('employment-type')?.value?.trim();
  const monthlyIncome = document.getElementById('monthly-income')?.value?.trim();
  const employerName = document.getElementById('employer-name')?.value?.trim();
  const retirementAge = document.getElementById('retirement-age')?.value?.trim();

  // Basic validation
  if (!employmentType || !monthlyIncome || !employerName) {
    alert("Please fill all required fields.");
    return;
  }

  // Create payload object
  const incomeData = {
    employmentType,
    monthlyIncome: parseFloat(monthlyIncome),
    employerName,
    retirementAge: retirementAge ? parseInt(retirementAge) : null
  };

  try {
    const response = await fetch("http://localhost:8093/income/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(incomeData)
    });

    const result = await response.json();

    if (response.ok && result?.data?.appId) {
      console.log("✅ Income saved. App ID:", result.data.appId);

      // 🔁 Carry forward appId to sessionStorage
      sessionStorage.setItem('appId', result.data.appId);

      // ⏩ Move to step 2 (PropertyDetails form)
      nextStep(2);
    } else {
      alert("❌ Failed to save income details: " + (result.message || "Unknown error"));
    }
  } catch (error) {
    console.error("🚫 Error while submitting income:", error);
    alert("An unexpected error occurred while saving income details.");
  }
}

/**********************************back button restricted***********************************************/

function warnBeforeBack() {
  const confirmLeave = confirm("⚠️ Any unsaved changes will be lost. Do you want to continue?");
  if (confirmLeave) {
    // Redirect to index or previous page
    window.location.href = "index.html";  // or any other page
  }
  // else do nothing, stay on page
}


/**********************************submit form for personal**************************************************/
function savePersonalDetailsAndNext() {
  const form = document.getElementById("personal-form");
  const formData = new FormData(form);
  const data = {};

  for (let [key, value] of formData.entries()) {
    data[key] = value.trim();
  }

  // Validate client-side
  const requiredFields = [
    "first-name", "last-name", "email-address", "phone-number",
    "date-of-birth", "gender", "nationality", "pan-number", "aadhar-number"
  ];

  for (const field of requiredFields) {
    const input = document.getElementById(field);
    if (!input || input.value.trim() === "") {
      alert(`Please fill in the required field: ${field}`);
      return;
    }
  }

  // Add appId from previous step
  const appId = sessionStorage.getItem("appId");

  if (!appId) {
    alert("Application ID not found. Please complete the previous step first.");
    return;
  }

  const personalDetails = {
    appId: appId,
    firstName: data["first-name"],
    lastName: data["last-name"],
    email: data["email-address"],
    phone: data["phone-number"],
    dob: data["date-of-birth"],
    gender: data["gender"],
    nationality: data["nationality"],
    pan: data["pan-number"],
    aadhar: data["aadhar-number"]
  };

  // Send POST to backend
  fetch("http://localhost:8093/personal/add", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(personalDetails)
  })
    .then(response => {
      if (!response.ok) throw new Error("Error saving personal details");
      return response.json();
    })
    .then(responseData => {
      console.log("Personal details saved:", responseData);
      nextStep(4); // Go to document upload
    })
    .catch(error => {
      console.error("Error:", error);
      alert("Failed to save personal details. Please try again.");
    });
}


/**********************************submit form for prpoerty**************************************************/
async function submitLoanPropertyDetails() {
  const appId = sessionStorage.getItem("appId");
  if (!appId) {
    alert("No Application ID found. Please fill Income Details first.");
    return;
  }

  const loanAmount = parseFloat(document.getElementById("loan-amount-required").value);
  const tenure = parseInt(document.getElementById("loan-tenure").value);
  const propertyCost = parseFloat(document.getElementById("property-cost").value);
  const propertyName = document.getElementById("property-name").value;
  const propertyLocation = document.getElementById("property-location").value;

  const payload = {
    appId,
    loanAmount,
    tenure,
    interestRate: 8.5,
    propertyCost,
    propertyName,
    propertyLocation
  };

  try {
    const res = await fetch("http://localhost:8093/loan-property/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || "Failed to save");
    }


    nextStep(3); // if multi-step form
  } catch (error) {
    console.error("🚫 Error submitting loan property details:", error);
    alert("An error occurred. Please try again.");
  }
}

/**********************************submit form for docuemtn**************************************************/
async function submitApplication() {


  const appId = sessionStorage.getItem('appId'); // ✅ match the saved key
  if (!appId) {
    alert("Missing Application ID. Please restart the application.");
    return;
  }
  //   try {
  //   const incomeResp = await submitIncomeDetails();
  //   const propertyResp = await submitLoanPropertyDetails();
  //   const personalResp = await savePersonalDetailsAndNext();

  //   if (incomeResp.ok && propertyResp.ok && personalResp.ok) {
  //     const documentResp = await uploadDocuments();
  //     if (!documentResp.ok) throw new Error("Upload failed");
  //   }
  // } catch (e) {
  //   console.error("Document upload error: " + e);
  //   alert("❌ Error uploading documents. Please try again.");
  // }

  await fetch("http://localhost:8093/tracker/update", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      appId: appId,
      statusUpdate: "Sent for Verification",
      dateApp: new Date().toISOString().split("T")[0] // YYYY-MM-DD
    })
  });

  const fileInputs = [
    { id: 'pan-card', type: 'PAN Card' },
    { id: 'aadhar-card', type: 'Aadhar Card' },
    { id: 'salary-slips', type: 'Salary Slips' },
    { id: 'bank-statements', type: 'Bank Statements' },
    { id: 'property-docs', type: 'Property Documents' },
    { id: 'other-docs', type: 'Other Documents' }
  ];

  const documents = [];

  fileInputs.forEach(input => {
    const files = document.getElementById(input.id).files;
    for (let i = 0; i < files.length; i++) {
      documents.push({
        appId,
        documentType: input.type,
        fileName: files[i].name
      });
    }
  });

  try {
    const response = await fetch("http://localhost:8093/documents/upload", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(documents)
    });

    if (!response.ok) throw new Error("Failed to upload documents");

    // // Update loan_tracker
    // await fetch("http://localhost:8093/tracker/update", {
    //     method: "POST",
    //     headers: {
    //         "Content-Type": "application/json"
    //     },
    //     body: JSON.stringify({
    //         appId: appId,
    //         statusUpdate: "Documents Uploaded",
    //         dateApp: new Date().toISOString().split("T")[0] // just "YYYY-MM-DD"

    //     })
    // });

    // Show success block
    document.getElementById("submission-status").style.display = "block";
    document.getElementById("app-id-display").innerText = appId;

  } catch (err) {
    console.error("Document upload error:", err);
    alert("❌ Error uploading documents. Please try again.");
  }
}

/////

function downloadSummary() {
  let summary = "Uploaded Documents:\n";

  if (Object.keys(uploadedFiles).length === 0) {
    summary += "No documents uploaded\n";
  } else {
    for (const [docType, files] of Object.entries(uploadedFiles)) {
      const names = Array.from(files).map(f => f.name).join(", ");
      summary += `${docType.replace(/-/g, " ")}: ${names}\n`;
    }
  }

  const appId = sessionStorage.getItem("appId");
  if (!appId) {
    alert("App ID not found in session.");
    return;
  }

  const url = `http://localhost:8093/documents/download-summary/${appId}`;
  window.open(url, "_blank");
}

/////////////////////////
function closeSuccessModal() {
  document.getElementById("success-modal").classList.remove("show")
  document.body.style.overflow = "auto"
  showSection("home")
}

function downloadApplicationCopy() {
  showNotification("Downloading application copy...", "info")
}

// File Upload Functions
function initializeDragAndDrop() {
  const uploadAreas = document.querySelectorAll(".upload-area")

  uploadAreas.forEach((area) => {
    area.addEventListener("dragover", (e) => {
      e.preventDefault()
      area.classList.add("drag-over")
    })

    area.addEventListener("dragleave", () => {
      area.classList.remove("drag-over")
    })

    area.addEventListener("drop", (e) => {
      e.preventDefault()
      area.classList.remove("drag-over")

      const files = e.dataTransfer.files
      const input = area.querySelector('input[type="file"]')

      if (files.length > 0) {
        input.files = files
        validateInput(input)
      }
    })
  })
}

function triggerFileUpload(inputId) {
  document.getElementById(inputId).click()
}


// function handleFileUpload(input) {
//   // uploadedFiles[input.id] = input.files; // Store files by input id
//   validateInput(input);
//   input.value = ""; // Reset so user can upload the same file again
// }
function handleFileUpload(input) {
  const inputId = input.id;
  const files = input.files;

  if (files.length > 0) {
    uploadedFiles[inputId] = files;
    document.getElementById(`${inputId}-status`).innerText = `${files.length} file(s) uploaded`;
  } else {
    delete uploadedFiles[inputId];
    document.getElementById(`${inputId}-status`).innerText = "No file selected";
  }

  validateInput(input);
}

// Tracker Functions
// function trackApplication() {
//   const applicationNumberInput = document.getElementById("application-number").value.trim()
//   const mobileNumberInput = document.getElementById("mobile-number").value.trim()

//   if (!applicationNumberInput || !mobileNumberInput) {
//     showNotification("Please enter both application number and mobile number.", "error")
//     document.getElementById("tracking-result").style.display = "none"
//     return
//   }

//   const allApplications = JSON.parse(localStorage.getItem("allApplications") || "[]")
//   const trackedApp = allApplications.find(
//     (app) =>
//       app.applicationNumber === applicationNumberInput &&
//       app.data.step3 &&
//       app.data.step3.phoneNumber === mobileNumberInput,
//   )

//   if (trackedApp) {
//     document.getElementById("tracked-app-number").textContent = `Application #${trackedApp.applicationNumber}`
//     document.getElementById("tracked-app-date").textContent =
//       `Applied on: ${new Date(trackedApp.submissionDate).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}`
//     renderTrackingTimeline(trackedApp.status)
//     document.getElementById("tracking-result").style.display = "block"
//     showNotification("Application found! Status updated.", "success")
//   } else {
//     document.getElementById("tracking-result").style.display = "none"
//     showNotification("Application not found. Please check your details.", "error")
//   }
// }

///

function showNotification(message, type) {
  alert(`${type.toUpperCase()}: ${message}`); // Simple alert, replace with custom if needed
}
// Call backend to track application by App ID
function trackApplication() {
  const applicationNumber = document.getElementById("application-number").value.trim();
  if (!applicationNumber) {
    showNotification("Please enter your application number.", "error");
    document.getElementById("tracking-result").style.display = "none";
    return;
  }
  fetch(`http://localhost:8080/api/latest-status/${applicationNumber}`)
    .then((response) => {
      if (!response.ok) throw new Error("Application not found");
      return response.json();
    })
    .then((data) => {
      document.getElementById("tracked-app-number").textContent = `Application #${data.appId}`;
      document.getElementById("tracked-app-date").textContent = `Updated on: ${new Date(
        data.dateApp
      ).toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      })}`;
      renderTrackingTimeline(data.statusUpdate);
      document.getElementById("tracking-result").style.display = "block";
      showNotification("Application found! Latest status displayed.", "success");
    })
    .catch((error) => {
      document.getElementById("tracking-result").style.display = "none";
      showNotification("Application not found. Please check the number.", "error");
    });
}
// Show status visually
function renderTrackingTimeline(status) {
  const timeline = document.getElementById("status-timeline");
  timeline.innerHTML = `
      <div class="status-item completed">
        <div class="status-dot"></div>
        <div class="status-text">${status}</div>
      </div>
    `;
}
//status fetch
// Call backend to track application by App ID
function fetchStatus() {
  const appId = document.getElementById("app-id-input").value.trim();
  const resultSection = document.getElementById("tracking-result");
  const appNumberEl = document.getElementById("tracked-app-number");
  const appDateEl = document.getElementById("tracked-app-date");
  const timeline = document.getElementById("status-timeline");
  if (!appId) {
    alert("Please enter Application ID");
    resultSection.style.display = "none";
    return;
  }
  fetch(`http://localhost:8082/api/status-history/${appId}`)
    .then((res) => {
      if (!res.ok) throw new Error("Application not found");
      return res.json();
    })
    .then((data) => {
      if (!Array.isArray(data) || data.length === 0) {
        throw new Error("No records found");
      }
      appNumberEl.textContent = `Application #${data[0].appId}`;
      appDateEl.textContent = `Updated on: ${new Date(data[data.length - 1].dateApp).toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      })}`;
      timeline.innerHTML = data.map(record => `
        <div class="status-item completed">
          <div class="status-dot"></div>
          <div class="status-text">
            <strong>${record.statusUpdate}</strong><br>
            <small>${new Date(record.dateApp).toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      })}</small>
          </div>
        </div>
      `).join('');
      resultSection.style.display = "block";
    })
    .catch((err) => {
      console.error(err);
      alert("Failed to fetch status. Please check the Application ID.");
      resultSection.style.display = "none";
    });
}


////


// function renderTrackingTimeline(status) {
//   const timelineEl = document.getElementById("status-timeline")
//   timelineEl.innerHTML = `
//     <div class="timeline-item ${getTimelineStatusClass("Under Consideration", status)}">
//         <div class="timeline-icon">
//             <i class="fas fa-file-alt"></i>
//         </div>
//         <div class="timeline-content">
//             <h4>Application Submitted</h4>
//             <p>Your application has been received and is being processed.</p>
//             <span class="timeline-date"></span>
//         </div>
//     </div>

//     <div class="timeline-item ${getTimelineStatusClass("Document Verification", status)}">
//         <div class="timeline-icon">
//             <i class="fas fa-file-check"></i>
//         </div>
//         <div class="timeline-content">
//             <h4>Document Verification</h4>
//             <p>All submitted documents have been verified successfully.</p>
//             <span class="timeline-date"></span>
//         </div>
//     </div>

//     <div class="timeline-item ${getTimelineStatusClass("Credit Assessment", status)}">
//         <div class="timeline-icon">
//             <i class="fas fa-search"></i>
//         </div>
//         <div class="timeline-content">
//             <h4>Credit Assessment</h4>
//             <p>Your credit profile is being evaluated by our team.</p>
//             <span class="timeline-date"></span>
//         </div>
//     </div>

//     <div class="timeline-item ${getTimelineStatusClass("Final Approval", status)}">
//         <div class="timeline-icon">
//             <i class="fas fa-clipboard-check"></i>
//         </div>
//         <div class="timeline-content">
//             <h4>Final Approval</h4>
//             <p>Pending final approval from the loan committee.</p>
//             <span class="timeline-date"></span>
//         </div>
//     </div>

//     <div class="timeline-item ${getTimelineStatusClass("Approved", status)}">
//         <div class="timeline-icon">
//             <i class="fas fa-money-check-alt"></i>
//         </div>
//         <div class="timeline-content">
//             <h4>Loan Disbursement</h4>
//             <p>Loan amount will be disbursed to your account.</p>
//             <span class="timeline-date"></span>
//         </div>
//     </div>
//   `

//   const statusOrder = [
//     "Under Consideration",
//     "Document Verification", // Simulated step
//     "Credit Assessment", // Simulated step
//     "Final Approval", // Simulated step
//     "Approved", // Final approved status
//   ]

//   const currentStatusIndex = statusOrder.indexOf(status)
//   const now = new Date()

//   timelineEl.querySelectorAll(".timeline-item").forEach((item, index) => {
//     const dateSpan = item.querySelector(".timeline-date")
//     const itemStatus = statusOrder[index]

//     if (status === "Rejected") {
//       // If rejected, mark all steps up to the point of rejection as completed
//       // For simplicity, we'll mark all previous steps as completed and the current one as active/completed
//       if (index <= currentStatusIndex) {
//         item.classList.add("completed")
//         dateSpan.textContent =
//           now.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) +
//           ", " +
//           now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })
//       } else {
//         item.classList.add("pending")
//         dateSpan.textContent = "Pending"
//       }
//       if (itemStatus === "Under Consideration") {
//         // Special handling for initial submission
//         item.classList.add("completed")
//       }
//     } else {
//       if (index < currentStatusIndex) {
//         item.classList.add("completed")
//         dateSpan.textContent =
//           now.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) +
//           ", " +
//           now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })
//       } else if (index === currentStatusIndex) {
//         item.classList.add("active")
//         dateSpan.textContent = "In Progress"
//       } else {
//         item.classList.add("pending")
//         dateSpan.textContent = "Pending"
//       }
//     }
//   })

//   // Special handling for "Approved" status to mark all as completed
//   if (status === "Approved") {
//     timelineEl.querySelectorAll(".timeline-item").forEach((item) => {
//       item.classList.remove("active", "pending")
//       item.classList.add("completed")
//       item.querySelector(".timeline-date").textContent =
//         now.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) +
//         ", " +
//         now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })
//     })
//   }
// }

function getTimelineStatusClass(stepName, currentStatus) {
  const statusOrder = [
    "Under Consideration",
    "Document Verification",
    "Credit Assessment",
    "Final Approval",
    "Approved",
  ]
  const currentStatusIndex = statusOrder.indexOf(currentStatus)
  const stepIndex = statusOrder.indexOf(stepName)

  if (currentStatus === "Rejected") {
    // If rejected, all steps up to the point of rejection are considered 'completed'
    // For simplicity, we'll mark all steps before 'Approved' as completed if rejected
    if (stepIndex < statusOrder.indexOf("Approved")) {
      return "completed"
    } else {
      return "pending"
    }
  } else if (stepIndex < currentStatusIndex) {
    return "completed"
  } else if (stepIndex === currentStatusIndex) {
    return "active"
  } else {
    return "pending"
  }
}

// My Applications Section
function renderMyApplications() {
  const myApplicationsTableBody = document.getElementById("my-applications-table-body")
  myApplicationsTableBody.innerHTML = ""

  if (!currentUser || !currentUser.id) {
    myApplicationsTableBody.innerHTML =
      '<tr><td colspan="6" class="text-center">Please log in to view your applications.</td></tr>'
    return
  }

  const allApplications = JSON.parse(localStorage.getItem("allApplications") || "[]")
  const userApplications = allApplications.filter((app) => app.userId === currentUser.id)

  if (userApplications.length === 0) {
    myApplicationsTableBody.innerHTML =
      '<tr><td colspan="6" class="text-center">You have not submitted any applications yet.</td></tr>'
    return
  }

  userApplications.forEach((app) => {
    const row = myApplicationsTableBody.insertRow()
    row.innerHTML = `
            <td>${app.applicationNumber}</td>
            <td>${formatCurrency(app.loanAmount)}</td>
            <td>${app.loanTenure} Years</td>
            <td><span class="status-badge ${app.status.toLowerCase().replace(/\s/g, "-")}">${app.status}</span></td>
            <td>${new Date(app.submissionDate).toLocaleDateString("en-IN")}</td>
            <td class="actions-cell">
                <button class="btn btn-sm btn-info" onclick="showSection('tracker'); document.getElementById('application-number').value='${app.applicationNumber}'; document.getElementById('mobile-number').value='${app.data.step3.phoneNumber}'; trackApplication();">View Status</button>
            </td>
        `
  })
}

// Utility Functions
function formatCurrency(amount) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount)
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2)
}

function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

function isValidPhone(phone) {
  const phoneRegex = /^[6-9]\d{9}$/
  return phoneRegex.test(phone.replace(/\D/g, ""))
}

function isValidPAN(pan) {
  const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/
  return panRegex.test(pan.toUpperCase())
}

function isValidAadhar(aadhar) {
  const aadharRegex = /^\d{12}$/
  return aadharRegex.test(aadhar.replace(/\D/g, ""))
}

// Form Validation Functions
function setupFormValidation(formId) {
  const form = document.getElementById(formId)
  if (!form) return

  const inputs = form.querySelectorAll('.form-input, select.form-input, input[type="file"]')

  inputs.forEach((input) => {
    input.addEventListener("input", () => validateInput(input))
    input.addEventListener("blur", () => validateInput(input))
    input.addEventListener("change", () => validateInput(input))
  })
}

function validateForm(formId) {
  const form = document.getElementById(formId)
  if (!form) return true

  const inputs = form.querySelectorAll('.form-input, select.form-input, input[type="file"]')
  let formIsValid = true

  inputs.forEach((input) => {
    if (!validateInput(input)) {
      formIsValid = false
    }
  })

  if (!formIsValid) {
    const firstInvalid = form.querySelector(
      '.form-input.invalid, select.form-input.invalid, input[type="file"].invalid',
    )
    if (firstInvalid) {
      firstInvalid.focus()
    }
  }
  return formIsValid
}

function validateInput(input) {
  const errorMessageElement = document.getElementById(`${input.id}-error`)
  let isValid = true
  let message = ""

  if (errorMessageElement) errorMessageElement.textContent = ""
  input.classList.remove("invalid", "valid")

  if (input.hasAttribute("required") && input.value.trim() === "") {
    isValid = false

  } else if (input.type === "email" && input.value.trim() !== "" && !isValidEmail(input.value)) {
    isValid = false
    message = "Please enter a valid email address."
  } else if (input.type === "tel" && input.value.trim() !== "" && !isValidPhone(input.value)) {
    isValid = false
    message = "Please enter a 10-digit phone number."
  } else if (input.id === "signup-password" && input.value.trim() !== "" && input.value.length < 6) {
    isValid = false
    message = "Password must be at least 6 characters long."
  } else if (
    input.id === "confirm-password" &&
    input.value.trim() !== "" &&
    input.value !== document.getElementById("signup-password").value
  ) {
    isValid = false
    message = "Passwords do not match."
  } else if (input.id === "pan-number" && input.value.trim() !== "" && !isValidPAN(input.value)) {
    isValid = false
    message = "Please enter a valid PAN number (e.g., ABCDE1234F)."
  } else if (input.id === "aadhar-number" && input.value.trim() !== "" && !isValidAadhar(input.value)) {
    isValid = false
    message = "Please enter a 12-digit Aadhar number."
  } else if (input.id === "pincode" && input.value.trim() !== "" && !/^\d{6}$/.test(input.value)) {
    isValid = false
    message = "Please enter a 6-digit pincode."
  } else if (
    input.type === "number" &&
    input.hasAttribute("min") &&
    Number.parseFloat(input.value) < Number.parseFloat(input.min)
  ) {
    isValid = false
    message = `Value cannot be less than ${input.min}.`
  } else if (input.type === "file") {
    const files = input.files
    const statusElement = document.getElementById(`${input.id}-status`)
    if (input.hasAttribute("required") && files.length === 0) {
      isValid = false
      message = "This document is required."
      if (statusElement) {
        statusElement.className = "upload-status error"
        statusElement.textContent = "No file selected."
      }
    } else if (files.length > 0) {
      let fileError = false
      for (let i = 0; i < files.length; i++) {
        const file = files[i]
        if (file.size > 5 * 1024 * 1024) {
          fileError = true
          message = `File "${file.name}" is too large (max 5MB).`
          break
        }
        const allowedTypes = ["application/pdf", "image/jpeg", "image/jpg", "image/png"]
        if (!allowedTypes.includes(file.type)) {
          fileError = true
          message = `File "${file.name}" has an unsupported format.`
          break
        }
      }
      if (fileError) {
        isValid = false
        if (statusElement) {
          statusElement.className = "upload-status error"
          statusElement.textContent = message
        }
      } else {
        if (statusElement) {
          statusElement.className = "upload-status success"
          statusElement.textContent = `${files.length} file(s) selected.`
        }
      }
    } else {
      if (statusElement) {
        statusElement.className = "upload-status"
        statusElement.textContent = ""
      }
    }
  }

  if (isValid) {
    input.classList.add("valid")
  } else {
    input.classList.add("invalid")
    if (errorMessageElement) errorMessageElement.textContent = message
  }
  return isValid
}

function resetFormValidation(formId) {
  const form = document.getElementById(formId)
  if (!form) return
  const inputs = form.querySelectorAll('.form-input, select.form-input, input[type="file"]')
  inputs.forEach((input) => {
    input.classList.remove("invalid", "valid")
    const errorMessageElement = document.getElementById(`${input.id}-error`)
    if (errorMessageElement) errorMessageElement.textContent = ""
    if (input.type === "file") {
      const statusElement = document.getElementById(`${input.id}-status`)
      if (statusElement) {
        statusElement.className = "upload-status"
        statusElement.textContent = ""
      }
      input.value = ""
    }
  })
  form.reset()
}

function clearFormErrors() {
  document.querySelectorAll(".error-message").forEach((el) => {
    el.textContent = ""
    el.style.display = "none"
  })

  document.querySelectorAll(".invalid").forEach((el) => {
    el.classList.remove("invalid")
  })
  document.querySelectorAll(".valid").forEach((el) => {
    el.classList.remove("valid")
  })
}

// Notification Functions
function showNotification(message, type = "info") {
  const toast = document.getElementById("notification-toast")
  if (!toast) return

  const icon = toast.querySelector(".toast-icon i")
  const title = toast.querySelector(".toast-title")
  const text = toast.querySelector(".toast-text")
  const toastIconBg = toast.querySelector(".toast-icon")

  text.textContent = message

  switch (type) {
    case "success":
      title.textContent = "Success!"
      icon.className = "fas fa-check-circle"
      if (toastIconBg) toastIconBg.style.background = "var(--success)"
      break
    case "error":
      title.textContent = "Error!"
      icon.className = "fas fa-exclamation-circle"
      if (toastIconBg) toastIconBg.style.background = "var(--error)"
      break
    case "warning":
      title.textContent = "Warning!"
      icon.className = "fas fa-exclamation-triangle"
      if (toastIconBg) toastIconBg.style.background = "var(--warning)"
      break
    default:
      title.textContent = "Info"
      icon.className = "fas fa-info-circle"
      if (toastIconBg) toastIconBg.style.background = "var(--info)"
  }

  toast.classList.add("show")

  setTimeout(() => {
    closeToast()
  }, 5000)
}

function closeToast() {
  const toast = document.getElementById("notification-toast")
  if (toast) toast.classList.remove("show")
}

function closeProfileMenu() {
  const userProfile = document.querySelector(".user-profile")
  const dropdown = document.getElementById("profile-dropdown")

  if (userProfile) userProfile.classList.remove("active")
  if (dropdown) dropdown.classList.remove("show")
}

// Handle window resize
window.addEventListener("resize", () => {
  if (window.innerWidth > 1024) {
    mobileMenu.classList.remove("show")
  }
})

// Prevent form submission on Enter key (except for textareas)
document.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && e.target.tagName !== "TEXTAREA" && e.target.type !== "submit") {
    e.preventDefault()
  }
})

// Add keyboard navigation support
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    closeScheduleModal()
    closeProfileMenu()
    mobileMenu.classList.remove("show")
    const adminModal = document.getElementById("view-application-modal")
    if (adminModal && adminModal.classList.contains("show")) {
      adminModal.classList.remove("show")
    }
  }
})

// Populate State and City Dropdowns
function populateStateDropdown() {
  const stateSelect = document.getElementById("state")
  if (!stateSelect) return

  stateSelect.innerHTML = '<option value="">Select State</option>'
  sortedStates.forEach((state) => {
    const option = document.createElement("option")
    option.value = state
    option.textContent = state
    stateSelect.appendChild(option)
  })
}

function populateCityDropdown() {
  const stateSelect = document.getElementById("state")
  const citySelect = document.getElementById("city")
  if (!stateSelect || !citySelect) return

  const selectedState = stateSelect.value
  citySelect.innerHTML = '<option value="">Select City</option>'

  if (selectedState && indianStatesAndCities[selectedState]) {
    const cities = indianStatesAndCities[selectedState].sort() // Sort cities alphabetically
    cities.forEach((city) => {
      const option = document.createElement("option")
      option.value = city
      option.textContent = city
      citySelect.appendChild(option)
    })
  }
}

console.log("JST Bank Application initialized successfully! 🏦")


///////////////////////////////////////////////////////////////////////////
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".upload-area").forEach(area => {
    area.addEventListener("click", (e) => {
      // Prevent double firing by checking if input was clicked directly
      if (e.target.tagName.toLowerCase() !== "input") {
        const input = area.querySelector("input[type='file']");
        if (input) input.click();
      }
    });
  });


  const form = document.getElementById("loanForm");

  if (form) {
    form.addEventListener("submit", async function (e) {
      e.preventDefault();

      const formData = {
        appId: form.appId.value,
        loanAmount: parseFloat(form.loanAmount.value),
        tenure: parseInt(form.tenure.value),
        interestRate: parseFloat(form.interestRate.value),
        user: {
          userId: form.userId.value,
        },
      };

      try {
        const response = await fetch("http://localhost:8080/loan/add", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        });

        const result = await response.json();
        alert("Loan Application Submitted ✅\n" + result.message);
        console.log(result);
      } catch (error) {
        alert("Failed to submit ❌");
        console.error("Submission error:", error);
      }
    });
  }
});

document.getElementById("signup-form").addEventListener("submit", async function (e) {
  e.preventDefault();

  const data = {
    firstName: document.getElementById("signup-firstname").value,
    lastName: document.getElementById("signup-lastname").value,
    email: document.getElementById("signup-email").value,
    password: document.getElementById("signup-password").value,
    phone: document.getElementById("signup-phone").value,
    // role: "Customer" // Optional, backend sets this
  };

  try {
    const res = await fetch("http://localhost:8879/api/users/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    if (!res.ok) {
      const error = await res.text();
      alert("Registration failed: " + error);
      return;
    }

    const json = await res.json();
    alert("Registration Successful! Welcome, " + json.firstName);

    showLogin();
    e.target.reset();
  } catch (err) {
    alert("Registration failed: " + err.message);
  }
});

document.getElementById("login-form").addEventListener("submit", async function (e) {
  e.preventDefault();

  const data = {
    email: document.getElementById("login-email").value,
    password: document.getElementById("login-password").value
  };

  try {
    const res = await fetch("http://localhost:8879/api/users/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    const json = await res.json();

    if (json.success) {
      localStorage.setItem("currentUser", JSON.stringify(json.user));
      alert("Login successful! Welcome, " + json.user.firstName);
      // Save user info to localStorage/sessionStorage if needed
      // Redirect to main app page, etc.
    } else {
      alert("Login failed: " + json.message);
    }
  } catch (err) {
    alert("Login failed: " + err.message);
  }
});

document.getElementById("admin-login-form").addEventListener("submit", async function (e) {
  e.preventDefault();

  const data = {
    email: document.getElementById("admin-email").value,
    password: document.getElementById("admin-password").value
  };

  try {
    const res = await fetch("http://localhost:8879/api/users/admin-login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    const json = await res.json();

    if (json.success) {
      alert("Admin login successful! Welcome, " + json.firstName);
      localStorage.setItem("adminLoggedIn", "true"); // <-- Set flag
      window.location.href = "admin.html";
    } else {
      alert("Admin login failed: " + json.message);
    }
  } catch (err) {
    alert("Admin login failed: " + err.message);
  }
});
//

let uploadedFiles = {};  // Key: inputId, Value: FileList or Array of files



