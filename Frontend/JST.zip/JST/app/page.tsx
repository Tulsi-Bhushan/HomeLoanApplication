"use client"

import { useState, useEffect } from "react"
import {
  Calculator,
  FileText,
  TrendingUp,
  Shield,
  Menu,
  X,
  Phone,
  Mail,
  MapPin,
  User,
  LogOut,
  Eye,
  EyeOff,
  CheckCircle,
  Clock,
  FileCheck,
  Zap,
  CreditCard,
  ArrowRight,
  Upload,
  Download,
  AlertCircle,
  Moon,
  Sun,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useTheme } from "next-themes"
import Image from "next/image"

export default function HomeLoanApp() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [showLogin, setShowLogin] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [showSignupPassword, setShowSignupPassword] = useState(false)
  const [activeSection, setActiveSection] = useState("home")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)
  const [user, setUser] = useState({ name: "", email: "" })
  const [showProfileDropdown, setShowProfileDropdown] = useState(false)

  // EMI Calculator states - Increased limits
  const [loanAmount, setLoanAmount] = useState([5000000]) // Default 50 lakhs
  const [tenure, setTenure] = useState([240]) // in months
  const [emiAmount, setEmiAmount] = useState(0)
  const [totalInterest, setTotalInterest] = useState(0)
  const [totalAmount, setTotalAmount] = useState(0)
  const [showSchedule, setShowSchedule] = useState(false)
  const [scheduleData, setScheduleData] = useState([])

  // Form states with validation
  const [loginForm, setLoginForm] = useState({ email: "", password: "" })
  const [signupForm, setSignupForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
  })

  // Application form states
  const [applicationData, setApplicationData] = useState({
    // Step 1: Income Details
    employmentType: "",
    monthlyIncome: "",
    organizationType: "",
    employerName: "",
    workExperience: "",
    retirementAge: "",

    // Step 2: Loan Details
    propertyLocation: "",
    propertyType: "",
    propertyCost: "",
    loanAmountRequired: "",
    loanTenure: "",

    // Step 3: Personal Details
    firstName: "",
    middleName: "",
    lastName: "",
    emailAddress: "",
    phoneNumber: "",
    dateOfBirth: "",
    gender: "",
    maritalStatus: "",
    nationality: "Indian",
    panNumber: "",
    aadharNumber: "",
    addressLine1: "",
    addressLine2: "",
    city: "",
    state: "",
    pincode: "",

    // Step 4: Documents
    documents: {},
  })

  const [formErrors, setFormErrors] = useState({})
  const [uploadedFiles, setUploadedFiles] = useState({})

  // Handle mounting for theme
  useEffect(() => {
    setMounted(true)
  }, [])

  // Calculate EMI whenever loan amount or tenure changes
  useEffect(() => {
    calculateEMI()
  }, [loanAmount, tenure])

  const calculateEMI = () => {
    const principal = loanAmount[0]
    const monthlyRate = 8.5 / (12 * 100) // 8.5% annual rate
    const numberOfPayments = tenure[0]

    if (principal > 0 && numberOfPayments > 0) {
      const emi =
        (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) /
        (Math.pow(1 + monthlyRate, numberOfPayments) - 1)

      const totalPay = emi * numberOfPayments
      const totalInt = totalPay - principal

      setEmiAmount(emi)
      setTotalAmount(totalPay)
      setTotalInterest(totalInt)

      // Generate schedule data
      generateScheduleData(principal, emi, monthlyRate, numberOfPayments)
    }
  }

  const generateScheduleData = (principal, emi, monthlyRate, numberOfPayments) => {
    const schedule = []
    let balance = principal

    for (let month = 1; month <= numberOfPayments; month++) {
      const interestPayment = balance * monthlyRate
      const principalPayment = emi - interestPayment
      balance -= principalPayment

      schedule.push({
        month,
        emi: emi,
        principal: principalPayment,
        interest: interestPayment,
        balance: Math.max(0, balance),
      })

      if (balance <= 0) break
    }

    setScheduleData(schedule)
  }

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const formatNumber = (num) => {
    return new Intl.NumberFormat("en-IN").format(num)
  }

  // Validation functions
  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  const validatePhone = (phone) => {
    const phoneRegex = /^[6-9]\d{9}$/
    return phoneRegex.test(phone)
  }

  const validatePAN = (pan) => {
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/
    return panRegex.test(pan)
  }

  const validateAadhar = (aadhar) => {
    const aadharRegex = /^\d{12}$/
    return aadharRegex.test(aadhar)
  }

  const validatePincode = (pincode) => {
    const pincodeRegex = /^\d{6}$/
    return pincodeRegex.test(pincode)
  }

  // Form validation for each step
  const validateStep = (step) => {
    const errors = {}

    switch (step) {
      case 1:
        if (!applicationData.employmentType) errors.employmentType = "Employment type is required"
        if (!applicationData.monthlyIncome) errors.monthlyIncome = "Monthly income is required"
        else if (Number.parseFloat(applicationData.monthlyIncome) <= 0)
          errors.monthlyIncome = "Please enter a valid income"
        if (!applicationData.organizationType) errors.organizationType = "Organization type is required"
        if (!applicationData.employerName) errors.employerName = "Employer name is required"
        if (!applicationData.workExperience) errors.workExperience = "Work experience is required"
        else if (Number.parseFloat(applicationData.workExperience) < 0)
          errors.workExperience = "Please enter valid experience"
        break

      case 2:
        if (!applicationData.propertyLocation) errors.propertyLocation = "Property location is required"
        if (!applicationData.propertyType) errors.propertyType = "Property type is required"
        if (!applicationData.propertyCost) errors.propertyCost = "Property cost is required"
        else if (Number.parseFloat(applicationData.propertyCost) <= 0)
          errors.propertyCost = "Please enter valid property cost"
        if (!applicationData.loanAmountRequired) errors.loanAmountRequired = "Loan amount is required"
        else if (Number.parseFloat(applicationData.loanAmountRequired) <= 0)
          errors.loanAmountRequired = "Please enter valid loan amount"
        else if (
          Number.parseFloat(applicationData.loanAmountRequired) >
          Number.parseFloat(applicationData.propertyCost) * 0.9
        ) {
          errors.loanAmountRequired = "Loan amount cannot exceed 90% of property cost"
        }
        if (!applicationData.loanTenure) errors.loanTenure = "Loan tenure is required"
        break

      case 3:
        if (!applicationData.firstName) errors.firstName = "First name is required"
        if (!applicationData.lastName) errors.lastName = "Last name is required"
        if (!applicationData.emailAddress) errors.emailAddress = "Email is required"
        else if (!validateEmail(applicationData.emailAddress)) errors.emailAddress = "Please enter a valid email"
        if (!applicationData.phoneNumber) errors.phoneNumber = "Phone number is required"
        else if (!validatePhone(applicationData.phoneNumber))
          errors.phoneNumber = "Please enter a valid 10-digit phone number"
        if (!applicationData.dateOfBirth) errors.dateOfBirth = "Date of birth is required"
        if (!applicationData.gender) errors.gender = "Gender is required"
        if (!applicationData.maritalStatus) errors.maritalStatus = "Marital status is required"
        if (!applicationData.panNumber) errors.panNumber = "PAN number is required"
        else if (!validatePAN(applicationData.panNumber))
          errors.panNumber = "Please enter a valid PAN number (e.g., ABCDE1234F)"
        if (!applicationData.aadharNumber) errors.aadharNumber = "Aadhar number is required"
        else if (!validateAadhar(applicationData.aadharNumber))
          errors.aadharNumber = "Please enter a valid 12-digit Aadhar number"
        if (!applicationData.addressLine1) errors.addressLine1 = "Address is required"
        if (!applicationData.city) errors.city = "City is required"
        if (!applicationData.state) errors.state = "State is required"
        if (!applicationData.pincode) errors.pincode = "Pincode is required"
        else if (!validatePincode(applicationData.pincode)) errors.pincode = "Please enter a valid 6-digit pincode"
        break

      case 4:
        const requiredDocs = ["panCard", "aadharCard", "salarySlips", "bankStatements"]
        requiredDocs.forEach((doc) => {
          if (!uploadedFiles[doc]) {
            errors[doc] = "This document is required"
          }
        })
        break
    }

    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }

  const handleLogin = (e) => {
    e.preventDefault()
    const errors = {}

    if (!loginForm.email) errors.email = "Email is required"
    else if (!validateEmail(loginForm.email)) errors.email = "Please enter a valid email"
    if (!loginForm.password) errors.password = "Password is required"

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors)
      return
    }

    // Simulate login
    setUser({ name: loginForm.email.split("@")[0], email: loginForm.email })
    setIsLoggedIn(true)
    setActiveSection("home")
    setFormErrors({})
  }

  const handleSignup = (e) => {
    e.preventDefault()
    const errors = {}

    if (!signupForm.name) errors.name = "Name is required"
    if (!signupForm.email) errors.email = "Email is required"
    else if (!validateEmail(signupForm.email)) errors.email = "Please enter a valid email"
    if (!signupForm.phone) errors.phone = "Phone number is required"
    else if (!validatePhone(signupForm.phone)) errors.phone = "Please enter a valid phone number"
    if (!signupForm.password) errors.password = "Password is required"
    else if (signupForm.password.length < 6) errors.password = "Password must be at least 6 characters"
    if (!signupForm.confirmPassword) errors.confirmPassword = "Please confirm your password"
    else if (signupForm.password !== signupForm.confirmPassword) errors.confirmPassword = "Passwords do not match"

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors)
      return
    }

    // Simulate signup
    setUser({ name: signupForm.name, email: signupForm.email })
    setIsLoggedIn(true)
    setActiveSection("home")
    setFormErrors({})
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setUser({ name: "", email: "" })
    setLoginForm({ email: "", password: "" })
    setSignupForm({ name: "", email: "", password: "", confirmPassword: "", phone: "" })
    setActiveSection("home")
    setShowProfileDropdown(false)
    setApplicationData({
      employmentType: "",
      monthlyIncome: "",
      organizationType: "",
      employerName: "",
      workExperience: "",
      retirementAge: "",
      propertyLocation: "",
      propertyType: "",
      propertyCost: "",
      loanAmountRequired: "",
      loanTenure: "",
      firstName: "",
      middleName: "",
      lastName: "",
      emailAddress: "",
      phoneNumber: "",
      dateOfBirth: "",
      gender: "",
      maritalStatus: "",
      nationality: "Indian",
      panNumber: "",
      aadharNumber: "",
      addressLine1: "",
      addressLine2: "",
      city: "",
      state: "",
      pincode: "",
      documents: {},
    })
    setUploadedFiles({})
    setCurrentStep(1)
  }

  const handleNextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevStep = () => {
    setCurrentStep(currentStep - 1)
  }

  const handleFileUpload = (docType, files) => {
    if (files && files.length > 0) {
      setUploadedFiles((prev) => ({
        ...prev,
        [docType]: Array.from(files),
      }))

      // Clear any existing error for this document
      setFormErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[docType]
        return newErrors
      })
    }
  }

  const handleApplicationSubmit = () => {
    if (validateStep(4)) {
      // Generate application number
      const applicationNumber = `JST${Date.now()}`

      // Save application data (in real app, this would go to backend)
      const finalApplicationData = {
        ...applicationData,
        applicationNumber,
        submissionDate: new Date().toISOString(),
        status: "submitted",
        documents: uploadedFiles,
      }

      localStorage.setItem("applicationData", JSON.stringify(finalApplicationData))

      alert(`Application submitted successfully! Your application number is: ${applicationNumber}`)

      // Reset form
      setCurrentStep(1)
      setApplicationData({
        employmentType: "",
        monthlyIncome: "",
        organizationType: "",
        employerName: "",
        workExperience: "",
        retirementAge: "",
        propertyLocation: "",
        propertyType: "",
        propertyCost: "",
        loanAmountRequired: "",
        loanTenure: "",
        firstName: "",
        middleName: "",
        lastName: "",
        emailAddress: "",
        phoneNumber: "",
        dateOfBirth: "",
        gender: "",
        maritalStatus: "",
        nationality: "Indian",
        panNumber: "",
        aadharNumber: "",
        addressLine1: "",
        addressLine2: "",
        city: "",
        state: "",
        pincode: "",
        documents: {},
      })
      setUploadedFiles({})
      setActiveSection("tracker")
    }
  }

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  // Don't render until mounted to avoid hydration mismatch
  if (!mounted) {
    return null
  }

  const LoginSignupPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-pink-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="absolute top-4 right-4">
            <Button
              onClick={toggleTheme}
              variant="outline"
              size="sm"
              className="border-teal-600 text-teal-600 hover:bg-teal-600 hover:text-white dark:border-teal-400 dark:text-teal-400 dark:hover:bg-teal-400 dark:hover:text-slate-900 bg-transparent"
            >
              {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            </Button>
          </div>
          <Image
            src="/assets/logo.png"
            alt="JST Bank"
            width={150}
            height={50}
            className="h-16 w-auto mx-auto mb-4 cursor-pointer hover:scale-105 transition-transform dark:filter dark:brightness-0 dark:invert"
            onClick={() => setActiveSection("home")}
          />
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">Welcome to JST Bank</h1>
          <p className="text-teal-600 dark:text-teal-400 font-medium italic">"Sapne kiraye pe nahi rehte"</p>
        </div>

        <Card className="shadow-2xl border-0 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm">
          <CardHeader className="pb-4">
            <Tabs value={showLogin ? "login" : "signup"} className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-slate-100 dark:bg-slate-700">
                <TabsTrigger
                  value="login"
                  onClick={() => setShowLogin(true)}
                  className="data-[state=active]:bg-teal-600 data-[state=active]:text-white dark:data-[state=active]:bg-teal-500"
                >
                  Login
                </TabsTrigger>
                <TabsTrigger
                  value="signup"
                  onClick={() => setShowLogin(false)}
                  className="data-[state=active]:bg-teal-600 data-[state=active]:text-white dark:data-[state=active]:bg-teal-500"
                >
                  Sign Up
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>

          <CardContent className="space-y-4">
            {showLogin ? (
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <Label htmlFor="email" className="text-slate-700 dark:text-slate-300">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={loginForm.email}
                    onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                    className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 focus:ring-teal-500 dark:bg-slate-700 dark:text-white"
                  />
                  {formErrors.email && <p className="text-red-500 text-sm mt-1">{formErrors.email}</p>}
                </div>
                <div>
                  <Label htmlFor="login-password" className="text-slate-700 dark:text-slate-300">
                    Password
                  </Label>
                  <div className="relative mt-1">
                    <Input
                      id="login-password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                      className="border-slate-300 dark:border-slate-600 focus:border-teal-500 focus:ring-teal-500 pr-10 dark:bg-slate-700 dark:text-white"
                      autoComplete="current-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300"
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                  {formErrors.password && <p className="text-red-500 text-sm mt-1">{formErrors.password}</p>}
                </div>
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white font-semibold py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Sign In
                </Button>
                <div className="text-center">
                  <a
                    href="#"
                    className="text-teal-600 dark:text-teal-400 hover:text-teal-700 dark:hover:text-teal-300 text-sm hover:underline"
                  >
                    Forgot your password?
                  </a>
                </div>
              </form>
            ) : (
              <form onSubmit={handleSignup} className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-slate-700 dark:text-slate-300">
                    Full Name
                  </Label>
                  <Input
                    id="name"
                    placeholder="Enter your full name"
                    value={signupForm.name}
                    onChange={(e) => setSignupForm({ ...signupForm, name: e.target.value })}
                    className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 focus:ring-teal-500 dark:bg-slate-700 dark:text-white"
                  />
                  {formErrors.name && <p className="text-red-500 text-sm mt-1">{formErrors.name}</p>}
                </div>
                <div>
                  <Label htmlFor="signup-email" className="text-slate-700 dark:text-slate-300">
                    Email Address
                  </Label>
                  <Input
                    id="signup-email"
                    type="email"
                    placeholder="Enter your email"
                    value={signupForm.email}
                    onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })}
                    className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 focus:ring-teal-500 dark:bg-slate-700 dark:text-white"
                  />
                  {formErrors.email && <p className="text-red-500 text-sm mt-1">{formErrors.email}</p>}
                </div>
                <div>
                  <Label htmlFor="phone" className="text-slate-700 dark:text-slate-300">
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="Enter your phone number"
                    value={signupForm.phone}
                    onChange={(e) => setSignupForm({ ...signupForm, phone: e.target.value })}
                    className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 focus:ring-teal-500 dark:bg-slate-700 dark:text-white"
                  />
                  {formErrors.phone && <p className="text-red-500 text-sm mt-1">{formErrors.phone}</p>}
                </div>
                <div>
                  <Label htmlFor="signup-password" className="text-slate-700 dark:text-slate-300">
                    Password
                  </Label>
                  <div className="relative mt-1">
                    <Input
                      id="signup-password"
                      type={showSignupPassword ? "text" : "password"}
                      placeholder="Create a password"
                      value={signupForm.password}
                      onChange={(e) => setSignupForm({ ...signupForm, password: e.target.value })}
                      className="border-slate-300 dark:border-slate-600 focus:border-teal-500 focus:ring-teal-500 pr-10 dark:bg-slate-700 dark:text-white"
                      autoComplete="new-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowSignupPassword(!showSignupPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300"
                    >
                      {showSignupPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                  {formErrors.password && <p className="text-red-500 text-sm mt-1">{formErrors.password}</p>}
                </div>
                <div>
                  <Label htmlFor="confirm-password" className="text-slate-700 dark:text-slate-300">
                    Confirm Password
                  </Label>
                  <Input
                    id="confirm-password"
                    type="password"
                    placeholder="Confirm your password"
                    value={signupForm.confirmPassword}
                    onChange={(e) => setSignupForm({ ...signupForm, confirmPassword: e.target.value })}
                    className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 focus:ring-teal-500 dark:bg-slate-700 dark:text-white"
                    autoComplete="new-password"
                  />
                  {formErrors.confirmPassword && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.confirmPassword}</p>
                  )}
                </div>
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white font-semibold py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Create Account
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const Navigation = () => (
    <nav className="bg-white dark:bg-slate-900 shadow-lg border-b border-slate-200 dark:border-slate-700 fixed top-0 w-full z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Image
              src="/assets/logo.png"
              alt="JST Bank"
              width={120}
              height={40}
              className="h-10 w-auto cursor-pointer hover:scale-105 transition-transform dark:filter dark:brightness-0 dark:invert"
              onClick={() => setActiveSection("home")}
            />
            <div className="ml-4 hidden md:block">
              <p className="text-teal-600 dark:text-teal-400 font-medium italic text-sm">
                "Sapne kiraye pe nahi rehte"
              </p>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            {["home", "calculator", "application", "tracker", "about"].map((section) => (
              <button
                key={section}
                onClick={() => setActiveSection(section)}
                className={`capitalize font-medium transition-all duration-300 hover:text-teal-600 dark:hover:text-teal-400 hover:scale-105 ${
                  activeSection === section
                    ? "text-teal-600 dark:text-teal-400 border-b-2 border-teal-600 dark:border-teal-400"
                    : "text-slate-700 dark:text-slate-300"
                }`}
              >
                {section === "tracker" ? "Track Loan" : section}
              </button>
            ))}

            <Button
              onClick={toggleTheme}
              variant="outline"
              size="sm"
              className="border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 bg-transparent"
            >
              {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            </Button>

            <div className="relative">
              <button
                onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                className="flex items-center space-x-2 text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 transition-colors"
              >
                <div className="w-8 h-8 bg-gradient-to-r from-teal-600 to-cyan-600 rounded-full flex items-center justify-center">
                  <User size={16} className="text-white" />
                </div>
                <span className="text-sm font-medium">{user.name}</span>
              </button>

              {showProfileDropdown && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-md shadow-lg py-1 z-50 border border-slate-200 dark:border-slate-700">
                  <div className="px-4 py-2 text-sm text-gray-700 dark:text-gray-300 border-b border-slate-200 dark:border-slate-700">
                    <div className="font-medium">{user.name}</div>
                    <div className="text-gray-500 dark:text-gray-400">{user.email}</div>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700"
                  >
                    <LogOut size={16} className="inline mr-2" />
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>

          <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? (
              <X className="text-slate-700 dark:text-slate-300" />
            ) : (
              <Menu className="text-slate-700 dark:text-slate-300" />
            )}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-2 border-t border-slate-200 dark:border-slate-700">
            {["home", "calculator", "application", "tracker", "about"].map((section) => (
              <button
                key={section}
                onClick={() => {
                  setActiveSection(section)
                  setMobileMenuOpen(false)
                }}
                className="block w-full text-left px-4 py-2 capitalize hover:bg-teal-50 dark:hover:bg-slate-800 hover:text-teal-600 dark:hover:text-teal-400 rounded transition-colors text-slate-700 dark:text-slate-300"
              >
                {section === "tracker" ? "Track Loan" : section}
              </button>
            ))}
            <div className="px-4 py-2 border-t border-slate-200 dark:border-slate-700">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600 dark:text-slate-400">{user.name}</span>
                <div className="flex space-x-2">
                  <Button onClick={toggleTheme} variant="outline" size="sm">
                    {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
                  </Button>
                  <Button onClick={handleLogout} variant="outline" size="sm">
                    <LogOut size={16} />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )

  const HeroSection = () => (
    <section className="bg-gradient-to-br from-teal-50 via-cyan-50 to-pink-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold text-slate-800 dark:text-white mb-4 leading-tight">
                Your Dream Home
                <span className="text-teal-600 dark:text-teal-400 block">Awaits You</span>
              </h1>
              <p className="text-xl text-slate-600 dark:text-slate-300 mb-6 leading-relaxed">
                Transform your homeownership dreams into reality with our hassle-free home loans, competitive rates, and
                lightning-fast approval process.
              </p>
              <p className="text-teal-600 dark:text-teal-400 font-semibold italic text-lg mb-8">
                "Sapne kiraye pe nahi rehte"
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => setActiveSection("application")}
                className="bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white px-8 py-4 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                Apply Now
                <ArrowRight className="ml-2" size={20} />
              </Button>
              <Button
                onClick={() => setActiveSection("calculator")}
                variant="outline"
                className="border-2 border-teal-600 dark:border-teal-400 text-teal-600 dark:text-teal-400 hover:bg-teal-600 hover:text-white dark:hover:bg-teal-400 dark:hover:text-slate-900 px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105"
              >
                <Calculator className="mr-2" size={20} />
                Calculate EMI
              </Button>
            </div>

            {/* Benefits Section */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-8">
              {[
                { icon: CheckCircle, text: "Pre-approved Limit", color: "text-teal-600 dark:text-teal-400" },
                { icon: Clock, text: "Quick Processing", color: "text-blue-600 dark:text-blue-400" },
                { icon: FileCheck, text: "Minimal Documents", color: "text-purple-600 dark:text-purple-400" },
                { icon: Zap, text: "Instant Approval", color: "text-orange-600 dark:text-orange-400" },
              ].map((benefit, index) => (
                <div
                  key={index}
                  className="text-center p-4 bg-white dark:bg-slate-800 rounded-lg shadow-sm hover:shadow-md transition-shadow"
                >
                  <benefit.icon className={`${benefit.color} mx-auto mb-2`} size={32} />
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-300">{benefit.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl p-8 hover:shadow-3xl transition-shadow duration-300">
              <div className="flex items-center mb-6">
                <Calculator className="text-teal-600 dark:text-teal-400 mr-3" size={28} />
                <h3 className="text-2xl font-bold text-slate-800 dark:text-white">EMI Calculator</h3>
              </div>
              <p className="text-slate-600 dark:text-slate-400 mb-6">Plan your home loan instalments better</p>

              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Loan Amount</Label>
                    <span className="text-teal-600 dark:text-teal-400 font-bold">₹{formatNumber(loanAmount[0])}</span>
                  </div>
                  <Slider
                    value={loanAmount}
                    onValueChange={setLoanAmount}
                    max={100000000} // Increased to 10 crores
                    min={100000}
                    step={50000}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mt-1">
                    <span>₹1L</span>
                    <span>₹10Cr</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Interest Rate</Label>
                    <span className="text-teal-600 dark:text-teal-400 font-bold">8.5%</span>
                  </div>
                  <div className="bg-slate-100 dark:bg-slate-700 rounded-lg p-3 text-center">
                    <span className="text-slate-600 dark:text-slate-400 text-sm">Fixed Rate</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Tenure</Label>
                    <span className="text-teal-600 dark:text-teal-400 font-bold">
                      {Math.round(tenure[0] / 12)} years
                    </span>
                  </div>
                  <Slider value={tenure} onValueChange={setTenure} max={360} min={12} step={12} className="w-full" />
                  <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mt-1">
                    <span>1 year</span>
                    <span>30 years</span>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-slate-800 to-slate-700 dark:from-slate-700 dark:to-slate-600 rounded-xl p-6 mt-6 text-white">
                <div className="text-center mb-4">
                  <p className="text-slate-300 text-sm mb-1">Your EMI is</p>
                  <p className="text-3xl font-bold">₹{formatNumber(Math.round(emiAmount))}</p>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-slate-300">Total Interest</p>
                    <p className="font-semibold">₹{formatNumber(Math.round(totalInterest))}</p>
                  </div>
                  <div>
                    <p className="text-slate-300">Total Amount</p>
                    <p className="font-semibold">₹{formatNumber(Math.round(totalAmount))}</p>
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <Button
                    onClick={() => setShowSchedule(true)}
                    variant="outline"
                    size="sm"
                    className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                  >
                    View Schedule
                  </Button>
                  <Button
                    onClick={() => setActiveSection("application")}
                    size="sm"
                    className="flex-1 bg-teal-600 hover:bg-teal-700"
                  >
                    Apply Now
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )

  const FeaturesSection = () => (
    <section className="py-20 bg-white dark:bg-slate-900">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-800 dark:text-white mb-4">
            Why Choose JST Bank for Your Home Loan?
          </h2>
          <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto">
            Experience the difference with our customer-centric approach and innovative banking solutions
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              icon: Calculator,
              title: "Smart EMI Calculator",
              desc: "Calculate your monthly EMI with our advanced calculator featuring real-time updates",
              color: "bg-teal-100 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400",
              hoverColor: "hover:bg-teal-600 hover:text-white dark:hover:bg-teal-500",
            },
            {
              icon: FileText,
              title: "Quick Application",
              desc: "Apply online with minimal documentation and experience our streamlined process",
              color: "bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400",
              hoverColor: "hover:bg-blue-600 hover:text-white dark:hover:bg-blue-500",
            },
            {
              icon: TrendingUp,
              title: "Real-time Tracking",
              desc: "Monitor your loan application status with our advanced tracking system",
              color: "bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400",
              hoverColor: "hover:bg-purple-600 hover:text-white dark:hover:bg-purple-500",
            },
            {
              icon: Shield,
              title: "Bank-grade Security",
              desc: "Your personal and financial data is protected with enterprise-level security",
              color: "bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400",
              hoverColor: "hover:bg-orange-600 hover:text-white dark:hover:bg-orange-500",
            },
          ].map((feature, index) => (
            <Card
              key={index}
              className="group hover:shadow-xl transition-all duration-300 hover:scale-105 border-0 shadow-lg dark:bg-slate-800 dark:border-slate-700"
            >
              <CardContent className="p-8 text-center">
                <div
                  className={`w-16 h-16 rounded-full ${feature.color} ${feature.hoverColor} mx-auto mb-6 flex items-center justify-center transition-all duration-300 group-hover:scale-110`}
                >
                  <feature.icon size={32} />
                </div>
                <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-3 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                  {feature.title}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">{feature.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Benefits Banner */}
        <div className="mt-16 bg-gradient-to-r from-teal-600 to-cyan-600 dark:from-teal-700 dark:to-cyan-700 rounded-2xl p-8 text-white">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold mb-2">6 Reasons to Choose Our Home Loan</h3>
            <p className="text-teal-100 dark:text-teal-200">Experience the JST Bank advantage</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {[
              { icon: CreditCard, title: "Pre-assigned Limit", desc: "Know your limit upfront" },
              { icon: Clock, title: "Money in 30 Minutes", desc: "Quick disbursement" },
              { icon: FileCheck, title: "No Documents Needed", desc: "Paperless process" },
              { icon: Zap, title: "Quicker Processing", desc: "Fast approval" },
              { icon: TrendingUp, title: "Loan up to ₹10 Crores", desc: "Higher loan amounts" },
              { icon: Shield, title: "Secure Process", desc: "100% safe & secure" },
            ].map((benefit, index) => (
              <div key={index} className="text-center group hover:scale-105 transition-transform">
                <div className="bg-white/20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3 group-hover:bg-white/30 transition-colors">
                  <benefit.icon size={24} />
                </div>
                <h4 className="font-semibold text-sm mb-1">{benefit.title}</h4>
                <p className="text-xs text-teal-100 dark:text-teal-200">{benefit.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )

  const CalculatorSection = () => (
    <section className="py-20 bg-gradient-to-br from-slate-50 to-teal-50 dark:from-slate-800 dark:to-slate-900">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-800 dark:text-white mb-4">
            Advanced EMI Calculator
          </h2>
          <p className="text-xl text-slate-600 dark:text-slate-400">Plan your home loan instalments with precision</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <Card className="shadow-xl border-0 dark:bg-slate-800 dark:border-slate-700">
            <CardHeader className="bg-gradient-to-r from-teal-600 to-cyan-600 text-white rounded-t-lg">
              <CardTitle className="text-2xl flex items-center">
                <Calculator className="mr-3" size={28} />
                Know Your EMI Outflow
              </CardTitle>
              <p className="text-teal-100">Estimate the monthly instalments on your home loan</p>
            </CardHeader>
            <CardContent className="p-8 space-y-8">
              <div>
                <div className="flex justify-between items-center mb-3">
                  <Label className="text-slate-700 dark:text-slate-300 font-semibold">Loan Amount (in Rupees)</Label>
                  <div className="bg-teal-50 dark:bg-teal-900/30 px-3 py-1 rounded-lg">
                    <span className="text-teal-700 dark:text-teal-400 font-bold">₹{formatNumber(loanAmount[0])}</span>
                  </div>
                </div>
                <Slider
                  value={loanAmount}
                  onValueChange={setLoanAmount}
                  max={100000000} // Increased to 10 crores
                  min={100000}
                  step={50000}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-slate-500 dark:text-slate-400 mt-2">
                  <span>₹1L</span>
                  <span>₹25L</span>
                  <span>₹50L</span>
                  <span>₹1Cr</span>
                  <span>₹5Cr</span>
                  <span>₹10Cr</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-3">
                  <Label className="text-slate-700 dark:text-slate-300 font-semibold">Interest Rate (%)</Label>
                  <div className="bg-blue-50 dark:bg-blue-900/30 px-3 py-1 rounded-lg">
                    <span className="text-blue-700 dark:text-blue-400 font-bold">8.5%</span>
                  </div>
                </div>
                <div className="bg-slate-100 dark:bg-slate-700 rounded-lg p-4 text-center border-2 border-dashed border-slate-300 dark:border-slate-600">
                  <span className="text-slate-600 dark:text-slate-400 font-medium">
                    Fixed Interest Rate - 8.5% per annum
                  </span>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-3">
                  <Label className="text-slate-700 dark:text-slate-300 font-semibold">Tenure (in months)</Label>
                  <div className="bg-purple-50 dark:bg-purple-900/30 px-3 py-1 rounded-lg">
                    <span className="text-purple-700 dark:text-purple-400 font-bold">{tenure[0]} months</span>
                  </div>
                </div>
                <Slider value={tenure} onValueChange={setTenure} max={360} min={12} step={12} className="w-full" />
                <div className="flex justify-between text-sm text-slate-500 dark:text-slate-400 mt-2">
                  <span>1Y</span>
                  <span>5Y</span>
                  <span>10Y</span>
                  <span>15Y</span>
                  <span>20Y</span>
                  <span>30Y</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card className="bg-gradient-to-br from-slate-800 to-slate-700 dark:from-slate-700 dark:to-slate-600 text-white shadow-xl border-0">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <p className="text-slate-300 text-lg mb-2">Your EMI is</p>
                  <p className="text-4xl font-bold text-white">₹{formatNumber(Math.round(emiAmount))}</p>
                </div>

                <div className="grid grid-cols-2 gap-6 mb-6">
                  <div className="text-center p-4 bg-white/10 rounded-lg">
                    <p className="text-slate-300 text-sm mb-1">Total Interest</p>
                    <p className="text-xl font-bold">₹{formatNumber(Math.round(totalInterest))}</p>
                  </div>
                  <div className="text-center p-4 bg-white/10 rounded-lg">
                    <p className="text-slate-300 text-sm mb-1">Total Amount Payable</p>
                    <p className="text-xl font-bold">₹{formatNumber(Math.round(totalAmount))}</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={() => setShowSchedule(true)}
                    variant="outline"
                    className="flex-1 border-slate-500 text-slate-300 hover:bg-slate-600 hover:border-slate-400 bg-transparent"
                  >
                    View Repayment Schedule
                  </Button>
                  <Button
                    onClick={() => setActiveSection("application")}
                    className="flex-1 bg-teal-600 hover:bg-teal-700 text-white font-semibold"
                  >
                    Apply Now
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 dark:bg-slate-800 dark:border-slate-700">
              <CardContent className="p-6">
                <h4 className="font-bold text-slate-800 dark:text-white mb-4">Loan Breakdown</h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-400">Principal Amount:</span>
                    <span className="font-semibold text-slate-800 dark:text-white">₹{formatNumber(loanAmount[0])}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-400">Total Interest:</span>
                    <span className="font-semibold text-slate-800 dark:text-white">
                      ₹{formatNumber(Math.round(totalInterest))}
                    </span>
                  </div>
                  <div className="flex justify-between border-t pt-2 dark:border-slate-600">
                    <span className="text-slate-600 dark:text-slate-400 font-semibold">Total Payable:</span>
                    <span className="font-bold text-teal-600 dark:text-teal-400">
                      ₹{formatNumber(Math.round(totalAmount))}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-pink-50 to-teal-50 dark:from-pink-900/20 dark:to-teal-900/20 border-teal-200 dark:border-teal-700 shadow-lg">
              <CardContent className="p-6">
                <h4 className="font-bold text-teal-800 dark:text-teal-400 mb-3">💡 Pro Tip</h4>
                <p className="text-teal-700 dark:text-teal-300 text-sm leading-relaxed">
                  Making additional payments towards your principal can significantly reduce your total interest and
                  loan tenure. Consider making extra payments when possible to save money in the long run.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Schedule Modal */}
      {showSchedule && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex justify-between items-center p-6 border-b dark:border-slate-700">
              <h3 className="text-xl font-bold text-slate-800 dark:text-white">Repayment Schedule</h3>
              <Button onClick={() => setShowSchedule(false)} variant="ghost" size="sm">
                <X size={20} />
              </Button>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 dark:bg-slate-700 rounded-lg">
                <div>
                  <span className="text-sm text-gray-600 dark:text-gray-400">Loan Amount:</span>
                  <div className="font-bold text-teal-600 dark:text-teal-400">₹{formatNumber(loanAmount[0])}</div>
                </div>
                <div>
                  <span className="text-sm text-gray-600 dark:text-gray-400">Interest Rate:</span>
                  <div className="font-bold text-teal-600 dark:text-teal-400">8.5% per annum</div>
                </div>
                <div>
                  <span className="text-sm text-gray-600 dark:text-gray-400">Tenure:</span>
                  <div className="font-bold text-teal-600 dark:text-teal-400">{Math.round(tenure[0] / 12)} years</div>
                </div>
                <div>
                  <span className="text-sm text-gray-600 dark:text-gray-400">Monthly EMI:</span>
                  <div className="font-bold text-teal-600 dark:text-teal-400">
                    ₹{formatNumber(Math.round(emiAmount))}
                  </div>
                </div>
              </div>

              <div className="overflow-auto max-h-96">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-teal-600 text-white">
                      <th className="border p-2 text-left">Month</th>
                      <th className="border p-2 text-right">EMI</th>
                      <th className="border p-2 text-right">Principal</th>
                      <th className="border p-2 text-right">Interest</th>
                      <th className="border p-2 text-right">Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {scheduleData.slice(0, 24).map((row, index) => (
                      <tr
                        key={index}
                        className={index % 2 === 0 ? "bg-gray-50 dark:bg-slate-700" : "bg-white dark:bg-slate-800"}
                      >
                        <td className="border dark:border-slate-600 p-2 text-slate-800 dark:text-white">{row.month}</td>
                        <td className="border dark:border-slate-600 p-2 text-right text-slate-800 dark:text-white">
                          ₹{formatNumber(Math.round(row.emi))}
                        </td>
                        <td className="border dark:border-slate-600 p-2 text-right text-slate-800 dark:text-white">
                          ₹{formatNumber(Math.round(row.principal))}
                        </td>
                        <td className="border dark:border-slate-600 p-2 text-right text-slate-800 dark:text-white">
                          ₹{formatNumber(Math.round(row.interest))}
                        </td>
                        <td className="border dark:border-slate-600 p-2 text-right text-slate-800 dark:text-white">
                          ₹{formatNumber(Math.round(row.balance))}
                        </td>
                      </tr>
                    ))}
                    {scheduleData.length > 24 && (
                      <tr>
                        <td
                          colSpan={5}
                          className="border dark:border-slate-600 p-2 text-center text-gray-500 dark:text-gray-400 italic"
                        >
                          ... and {scheduleData.length - 24} more months
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              <div className="mt-4 flex justify-end">
                <Button
                  onClick={() => {
                    // In a real app, this would generate and download a PDF
                    alert("Schedule download feature would be implemented here")
                  }}
                  className="bg-teal-600 hover:bg-teal-700"
                >
                  <Download size={16} className="mr-2" />
                  Download Schedule
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  )

  const ApplicationSection = () => (
    <section className="py-20 bg-white dark:bg-slate-900">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-800 dark:text-white mb-4">Home Loan Application</h2>
          <p className="text-xl text-slate-600 dark:text-slate-400">Complete your application in simple steps</p>
        </div>

        <div className="flex justify-center mb-8">
          <div className="flex space-x-4">
            {[
              { step: 1, title: "Income Details" },
              { step: 2, title: "Loan Details" },
              { step: 3, title: "Personal Details" },
              { step: 4, title: "Upload Documents" },
            ].map((item) => (
              <div
                key={item.step}
                className={`flex items-center px-4 py-2 rounded-full font-semibold transition-all duration-300 ${
                  currentStep === item.step
                    ? "bg-teal-600 text-white shadow-lg scale-105"
                    : currentStep > item.step
                      ? "bg-green-600 text-white"
                      : "bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600"
                }`}
              >
                <span className="mr-2">{item.step}.</span>
                <span className="hidden sm:inline">{item.title}</span>
              </div>
            ))}
          </div>
        </div>

        <Card className="shadow-xl border-0 dark:bg-slate-800 dark:border-slate-700">
          <CardContent className="p-8">
            {currentStep === 1 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-6 text-center">Income Details</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Type of Employment *</Label>
                    <Select
                      value={applicationData.employmentType}
                      onValueChange={(value) => setApplicationData({ ...applicationData, employmentType: value })}
                    >
                      <SelectTrigger className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white">
                        <SelectValue placeholder="Select Employment Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="salaried">Salaried</SelectItem>
                        <SelectItem value="self-employed">Self Employed</SelectItem>
                        <SelectItem value="business">Business Owner</SelectItem>
                      </SelectContent>
                    </Select>
                    {formErrors.employmentType && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.employmentType}</p>
                    )}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Monthly Income (₹) *</Label>
                    <Input
                      type="number"
                      placeholder="Enter your monthly income"
                      value={applicationData.monthlyIncome}
                      onChange={(e) => setApplicationData({ ...applicationData, monthlyIncome: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.monthlyIncome && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.monthlyIncome}</p>
                    )}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Organization Type *</Label>
                    <Select
                      value={applicationData.organizationType}
                      onValueChange={(value) => setApplicationData({ ...applicationData, organizationType: value })}
                    >
                      <SelectTrigger className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white">
                        <SelectValue placeholder="Select Organization Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="government">Government</SelectItem>
                        <SelectItem value="private">Private</SelectItem>
                        <SelectItem value="psu">PSU</SelectItem>
                        <SelectItem value="mnc">MNC</SelectItem>
                      </SelectContent>
                    </Select>
                    {formErrors.organizationType && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.organizationType}</p>
                    )}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Employer Name *</Label>
                    <Input
                      placeholder="Enter employer name"
                      value={applicationData.employerName}
                      onChange={(e) => setApplicationData({ ...applicationData, employerName: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.employerName && <p className="text-red-500 text-sm mt-1">{formErrors.employerName}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Work Experience (Years) *</Label>
                    <Input
                      type="number"
                      placeholder="Enter work experience"
                      value={applicationData.workExperience}
                      onChange={(e) => setApplicationData({ ...applicationData, workExperience: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.workExperience && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.workExperience}</p>
                    )}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Retirement Age</Label>
                    <Input
                      type="number"
                      placeholder="Enter retirement age"
                      value={applicationData.retirementAge}
                      onChange={(e) => setApplicationData({ ...applicationData, retirementAge: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                  </div>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-6 text-center">Loan Details</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Property Location *</Label>
                    <Input
                      placeholder="Enter property location"
                      value={applicationData.propertyLocation}
                      onChange={(e) => setApplicationData({ ...applicationData, propertyLocation: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.propertyLocation && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.propertyLocation}</p>
                    )}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Property Type *</Label>
                    <Select
                      value={applicationData.propertyType}
                      onValueChange={(value) => setApplicationData({ ...applicationData, propertyType: value })}
                    >
                      <SelectTrigger className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white">
                        <SelectValue placeholder="Select Property Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="apartment">Apartment</SelectItem>
                        <SelectItem value="villa">Villa</SelectItem>
                        <SelectItem value="plot">Plot</SelectItem>
                        <SelectItem value="commercial">Commercial</SelectItem>
                      </SelectContent>
                    </Select>
                    {formErrors.propertyType && <p className="text-red-500 text-sm mt-1">{formErrors.propertyType}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Property Cost (₹) *</Label>
                    <Input
                      type="number"
                      placeholder="Enter property cost"
                      value={applicationData.propertyCost}
                      onChange={(e) => setApplicationData({ ...applicationData, propertyCost: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.propertyCost && <p className="text-red-500 text-sm mt-1">{formErrors.propertyCost}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Loan Amount Required (₹) *</Label>
                    <Input
                      type="number"
                      placeholder="Enter loan amount"
                      value={applicationData.loanAmountRequired}
                      onChange={(e) => setApplicationData({ ...applicationData, loanAmountRequired: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.loanAmountRequired && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.loanAmountRequired}</p>
                    )}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Loan Tenure (Years) *</Label>
                    <Select
                      value={applicationData.loanTenure}
                      onValueChange={(value) => setApplicationData({ ...applicationData, loanTenure: value })}
                    >
                      <SelectTrigger className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white">
                        <SelectValue placeholder="Select Tenure" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="5">5 Years</SelectItem>
                        <SelectItem value="10">10 Years</SelectItem>
                        <SelectItem value="15">15 Years</SelectItem>
                        <SelectItem value="20">20 Years</SelectItem>
                        <SelectItem value="25">25 Years</SelectItem>
                        <SelectItem value="30">30 Years</SelectItem>
                      </SelectContent>
                    </Select>
                    {formErrors.loanTenure && <p className="text-red-500 text-sm mt-1">{formErrors.loanTenure}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Interest Rate</Label>
                    <div className="mt-1 p-3 bg-slate-100 dark:bg-slate-700 rounded-md border-2 border-dashed border-slate-300 dark:border-slate-600">
                      <span className="text-teal-600 dark:text-teal-400 font-bold">8.5% per annum (Fixed)</span>
                    </div>
                  </div>
                </div>

                {applicationData.monthlyIncome && (
                  <div className="mt-6 p-4 bg-teal-50 dark:bg-teal-900/20 rounded-lg border border-teal-200 dark:border-teal-700">
                    <h4 className="font-bold text-teal-800 dark:text-teal-400 mb-2">Loan Eligibility</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm text-teal-600 dark:text-teal-400">Maximum Eligible Amount:</span>
                        <div className="font-bold text-teal-800 dark:text-teal-300">
                          ₹{formatNumber(Number.parseFloat(applicationData.monthlyIncome || 0) * 60)}
                        </div>
                      </div>
                      <div>
                        <span className="text-sm text-teal-600 dark:text-teal-400">Estimated EMI:</span>
                        <div className="font-bold text-teal-800 dark:text-teal-300">
                          ₹{formatNumber(Math.round(Number.parseFloat(applicationData.monthlyIncome || 0) * 0.4))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-6 text-center">Personal Details</h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">First Name *</Label>
                    <Input
                      placeholder="Enter first name"
                      value={applicationData.firstName}
                      onChange={(e) => setApplicationData({ ...applicationData, firstName: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.firstName && <p className="text-red-500 text-sm mt-1">{formErrors.firstName}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Middle Name</Label>
                    <Input
                      placeholder="Enter middle name"
                      value={applicationData.middleName}
                      onChange={(e) => setApplicationData({ ...applicationData, middleName: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Last Name *</Label>
                    <Input
                      placeholder="Enter last name"
                      value={applicationData.lastName}
                      onChange={(e) => setApplicationData({ ...applicationData, lastName: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.lastName && <p className="text-red-500 text-sm mt-1">{formErrors.lastName}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Email Address *</Label>
                    <Input
                      type="email"
                      placeholder="Enter email address"
                      value={applicationData.emailAddress}
                      onChange={(e) => setApplicationData({ ...applicationData, emailAddress: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.emailAddress && <p className="text-red-500 text-sm mt-1">{formErrors.emailAddress}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Phone Number *</Label>
                    <Input
                      type="tel"
                      placeholder="Enter phone number"
                      value={applicationData.phoneNumber}
                      onChange={(e) => setApplicationData({ ...applicationData, phoneNumber: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.phoneNumber && <p className="text-red-500 text-sm mt-1">{formErrors.phoneNumber}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Date of Birth *</Label>
                    <Input
                      type="date"
                      value={applicationData.dateOfBirth}
                      onChange={(e) => setApplicationData({ ...applicationData, dateOfBirth: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                    {formErrors.dateOfBirth && <p className="text-red-500 text-sm mt-1">{formErrors.dateOfBirth}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Gender *</Label>
                    <Select
                      value={applicationData.gender}
                      onValueChange={(value) => setApplicationData({ ...applicationData, gender: value })}
                    >
                      <SelectTrigger className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white">
                        <SelectValue placeholder="Select Gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    {formErrors.gender && <p className="text-red-500 text-sm mt-1">{formErrors.gender}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Marital Status *</Label>
                    <Select
                      value={applicationData.maritalStatus}
                      onValueChange={(value) => setApplicationData({ ...applicationData, maritalStatus: value })}
                    >
                      <SelectTrigger className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white">
                        <SelectValue placeholder="Select Marital Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="single">Single</SelectItem>
                        <SelectItem value="married">Married</SelectItem>
                        <SelectItem value="divorced">Divorced</SelectItem>
                        <SelectItem value="widowed">Widowed</SelectItem>
                      </SelectContent>
                    </Select>
                    {formErrors.maritalStatus && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.maritalStatus}</p>
                    )}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Nationality *</Label>
                    <Input
                      placeholder="Enter nationality"
                      value={applicationData.nationality}
                      onChange={(e) => setApplicationData({ ...applicationData, nationality: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">PAN Number *</Label>
                    <Input
                      placeholder="Enter PAN number (e.g., ABCDE1234F)"
                      value={applicationData.panNumber}
                      onChange={(e) =>
                        setApplicationData({ ...applicationData, panNumber: e.target.value.toUpperCase() })
                      }
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                      maxLength={10}
                    />
                    {formErrors.panNumber && <p className="text-red-500 text-sm mt-1">{formErrors.panNumber}</p>}
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-300 font-medium">Aadhar Number *</Label>
                    <Input
                      placeholder="Enter 12-digit Aadhar number"
                      value={applicationData.aadharNumber}
                      onChange={(e) => setApplicationData({ ...applicationData, aadharNumber: e.target.value })}
                      className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                      maxLength={12}
                    />
                    {formErrors.aadharNumber && <p className="text-red-500 text-sm mt-1">{formErrors.aadharNumber}</p>}
                  </div>
                </div>

                <div className="border-t dark:border-slate-600 pt-6">
                  <h4 className="text-lg font-bold text-slate-800 dark:text-white mb-4">Address Details</h4>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                      <Label className="text-slate-700 dark:text-slate-300 font-medium">Address Line 1 *</Label>
                      <Input
                        placeholder="Enter address line 1"
                        value={applicationData.addressLine1}
                        onChange={(e) => setApplicationData({ ...applicationData, addressLine1: e.target.value })}
                        className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                      />
                      {formErrors.addressLine1 && (
                        <p className="text-red-500 text-sm mt-1">{formErrors.addressLine1}</p>
                      )}
                    </div>
                    <div className="md:col-span-2">
                      <Label className="text-slate-700 dark:text-slate-300 font-medium">Address Line 2</Label>
                      <Input
                        placeholder="Enter address line 2"
                        value={applicationData.addressLine2}
                        onChange={(e) => setApplicationData({ ...applicationData, addressLine2: e.target.value })}
                        className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-slate-700 dark:text-slate-300 font-medium">City *</Label>
                      <Input
                        placeholder="Enter city"
                        value={applicationData.city}
                        onChange={(e) => setApplicationData({ ...applicationData, city: e.target.value })}
                        className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                      />
                      {formErrors.city && <p className="text-red-500 text-sm mt-1">{formErrors.city}</p>}
                    </div>
                    <div>
                      <Label className="text-slate-700 dark:text-slate-300 font-medium">State *</Label>
                      <Input
                        placeholder="Enter state"
                        value={applicationData.state}
                        onChange={(e) => setApplicationData({ ...applicationData, state: e.target.value })}
                        className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                      />
                      {formErrors.state && <p className="text-red-500 text-sm mt-1">{formErrors.state}</p>}
                    </div>
                    <div>
                      <Label className="text-slate-700 dark:text-slate-300 font-medium">Pincode *</Label>
                      <Input
                        placeholder="Enter 6-digit pincode"
                        value={applicationData.pincode}
                        onChange={(e) => setApplicationData({ ...applicationData, pincode: e.target.value })}
                        className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                        maxLength={6}
                      />
                      {formErrors.pincode && <p className="text-red-500 text-sm mt-1">{formErrors.pincode}</p>}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-6 text-center">Upload Documents</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  {[
                    { id: "panCard", title: "PAN Card", required: true, icon: FileText },
                    { id: "aadharCard", title: "Aadhar Card", required: true, icon: FileText },
                    { id: "salarySlips", title: "Salary Slips (Last 3 months)", required: true, icon: FileText },
                    { id: "bankStatements", title: "Bank Statements (Last 6 months)", required: true, icon: FileText },
                    { id: "propertyDocs", title: "Property Documents", required: false, icon: FileText },
                    { id: "otherDocs", title: "Other Documents", required: false, icon: FileText },
                  ].map((doc) => (
                    <div
                      key={doc.id}
                      className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg p-6 hover:border-teal-400 dark:hover:border-teal-500 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <doc.icon className="text-teal-600 dark:text-teal-400 mr-2" size={20} />
                          <h4 className="font-medium text-slate-700 dark:text-slate-300">{doc.title}</h4>
                        </div>
                        {doc.required && (
                          <span className="bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400 text-xs px-2 py-1 rounded">
                            Required
                          </span>
                        )}
                      </div>

                      <div className="text-center">
                        <input
                          type="file"
                          id={doc.id}
                          multiple={doc.id === "salarySlips" || doc.id === "bankStatements"}
                          accept=".pdf,.jpg,.jpeg,.png"
                          onChange={(e) => handleFileUpload(doc.id, e.target.files)}
                          className="hidden"
                        />
                        <label
                          htmlFor={doc.id}
                          className="cursor-pointer inline-flex items-center px-4 py-2 border border-teal-600 dark:border-teal-400 text-teal-600 dark:text-teal-400 rounded-md hover:bg-teal-600 hover:text-white dark:hover:bg-teal-400 dark:hover:text-slate-900 transition-colors"
                        >
                          <Upload size={16} className="mr-2" />
                          Choose Files
                        </label>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">PDF, JPG, PNG (Max 5MB each)</p>
                      </div>

                      {uploadedFiles[doc.id] && (
                        <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 rounded">
                          <p className="text-green-800 dark:text-green-400 text-sm font-medium">
                            ✓ {uploadedFiles[doc.id].length} file(s) uploaded
                          </p>
                          <div className="text-xs text-green-600 dark:text-green-400 mt-1">
                            {uploadedFiles[doc.id].map((file, index) => (
                              <div key={index}>{file.name}</div>
                            ))}
                          </div>
                        </div>
                      )}

                      {formErrors[doc.id] && <p className="text-red-500 text-sm mt-2">{formErrors[doc.id]}</p>}
                    </div>
                  ))}
                </div>

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Document Guidelines:</strong>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      <li>All documents should be clear and readable</li>
                      <li>Accepted formats: PDF, JPG, JPEG, PNG</li>
                      <li>Maximum file size: 5MB per document</li>
                      <li>Ensure all personal information is visible</li>
                      <li>Documents should not be older than 3 months (except PAN/Aadhar)</li>
                    </ul>
                  </AlertDescription>
                </Alert>
              </div>
            )}

            <div className="flex justify-between mt-8 pt-6 border-t border-slate-200 dark:border-slate-600">
              {currentStep > 1 && (
                <Button
                  onClick={handlePrevStep}
                  variant="outline"
                  className="border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 bg-transparent"
                >
                  Previous
                </Button>
              )}
              <div className="ml-auto">
                {currentStep < 4 ? (
                  <Button
                    onClick={handleNextStep}
                    className="bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white px-8"
                  >
                    Next Step
                    <ArrowRight className="ml-2" size={16} />
                  </Button>
                ) : (
                  <Button
                    onClick={handleApplicationSubmit}
                    className="bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white px-8"
                  >
                    Submit Application
                    <CheckCircle className="ml-2" size={16} />
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )

  const TrackerSection = () => (
    <section className="py-20 bg-gradient-to-br from-slate-50 to-teal-50 dark:from-slate-800 dark:to-slate-900">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-800 dark:text-white mb-4">
            Track Your Loan Application
          </h2>
          <p className="text-xl text-slate-600 dark:text-slate-400">
            Stay updated with real-time status of your application
          </p>
        </div>

        <Card className="shadow-xl border-0 mb-8 dark:bg-slate-800 dark:border-slate-700">
          <CardContent className="p-8">
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div>
                <Label className="text-slate-700 dark:text-slate-300 font-medium">Application Number</Label>
                <Input
                  placeholder="Enter application number"
                  className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                />
              </div>
              <div>
                <Label className="text-slate-700 dark:text-slate-300 font-medium">Mobile Number</Label>
                <Input
                  placeholder="Enter mobile number"
                  className="mt-1 border-slate-300 dark:border-slate-600 focus:border-teal-500 dark:bg-slate-700 dark:text-white"
                />
              </div>
            </div>
            <Button className="w-full bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white font-semibold py-3">
              Track Application
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-xl border-0 dark:bg-slate-800 dark:border-slate-700">
          <CardHeader className="bg-gradient-to-r from-teal-600 to-cyan-600 text-white">
            <CardTitle className="text-2xl text-center">Application Status</CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            <div className="space-y-6">
              {[
                {
                  status: "Application Submitted",
                  desc: "Your application has been received and is being processed",
                  completed: true,
                  icon: CheckCircle,
                  color: "text-teal-600 dark:text-teal-400",
                  bgColor: "bg-teal-50 dark:bg-teal-900/20",
                  borderColor: "border-teal-500 dark:border-teal-400",
                },
                {
                  status: "Under Verification",
                  desc: "Documents are being verified by our team",
                  active: true,
                  icon: Clock,
                  color: "text-amber-600 dark:text-amber-400",
                  bgColor: "bg-amber-50 dark:bg-amber-900/20",
                  borderColor: "border-amber-500 dark:border-amber-400",
                },
                {
                  status: "Final Approval",
                  desc: "Pending final approval from the loan committee",
                  completed: false,
                  icon: FileCheck,
                  color: "text-slate-400",
                  bgColor: "bg-slate-50 dark:bg-slate-700",
                  borderColor: "border-slate-300 dark:border-slate-600",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className={`flex items-center p-6 rounded-xl border-l-4 ${item.borderColor} ${item.bgColor} hover:shadow-md transition-all duration-300`}
                >
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center mr-6 ${
                      item.completed
                        ? "bg-teal-600 text-white"
                        : item.active
                          ? "bg-amber-500 text-white"
                          : "bg-slate-300 dark:bg-slate-600 text-slate-600 dark:text-slate-400"
                    }`}
                  >
                    <item.icon size={24} />
                  </div>
                  <div className="flex-1">
                    <h4 className={`font-bold text-lg mb-1 ${item.color}`}>{item.status}</h4>
                    <p className="text-slate-600 dark:text-slate-400">{item.desc}</p>
                  </div>
                  {item.completed && <div className="text-teal-600 dark:text-teal-400 font-semibold">✓ Completed</div>}
                  {item.active && (
                    <div className="text-amber-600 dark:text-amber-400 font-semibold">⏳ In Progress</div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )

  const AboutSection = () => (
    <section className="py-20 bg-white dark:bg-slate-900">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-800 dark:text-white mb-4">About JST Bank</h2>
          <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto leading-relaxed">
            JST Bank is committed to making your dream of owning a home a reality. We provide hassle-free, user-friendly
            online platform for home loan applications with competitive interest rates and lightning-fast approval
            processes.
          </p>
          <p className="text-2xl text-teal-600 dark:text-teal-400 font-bold italic mt-6">
            "Sapne kiraye pe nahi rehte"
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {[
            {
              title: "Our Mission",
              desc: "To simplify the home loan process and make homeownership accessible to everyone through innovative digital banking solutions.",
              icon: TrendingUp,
              color: "text-teal-600 dark:text-teal-400",
            },
            {
              title: "Our Vision",
              desc: "To be the leading digital banking solution for home loans in India, setting new standards for customer experience.",
              icon: Shield,
              color: "text-blue-600 dark:text-blue-400",
            },
            {
              title: "Our Values",
              desc: "Transparency, Customer-centricity, Innovation, Trust, and Excellence in everything we do for our customers.",
              icon: CheckCircle,
              color: "text-purple-600 dark:text-purple-400",
            },
          ].map((item, index) => (
            <Card
              key={index}
              className="group hover:shadow-xl transition-all duration-300 hover:scale-105 border-0 shadow-lg dark:bg-slate-800 dark:border-slate-700"
            >
              <CardContent className="p-8 text-center">
                <div
                  className={`w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-700 ${item.color} mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform`}
                >
                  <item.icon size={32} />
                </div>
                <h4 className="font-bold text-xl text-slate-800 dark:text-white mb-4 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                  {item.title}
                </h4>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">{item.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="bg-gradient-to-r from-teal-600 to-cyan-600 dark:from-teal-700 dark:to-cyan-700 rounded-2xl p-12 text-white text-center">
          <h3 className="text-3xl font-bold mb-4">Ready to Make Your Dream Home a Reality?</h3>
          <p className="text-xl text-teal-100 dark:text-teal-200 mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who have trusted JST Bank for their home loan needs. Experience the
            difference with our customer-first approach.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={() => setActiveSection("application")}
              className="bg-white text-teal-600 hover:bg-teal-50 px-8 py-3 text-lg font-semibold"
            >
              Start Your Application
            </Button>
            <Button
              onClick={() => setActiveSection("calculator")}
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-teal-600 px-8 py-3 text-lg font-semibold"
            >
              Calculate EMI
            </Button>
          </div>
        </div>
      </div>
    </section>
  )

  const Footer = () => (
    <footer className="bg-slate-800 dark:bg-slate-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div>
            <Image
              src="/assets/logo.png"
              alt="JST Bank"
              width={120}
              height={40}
              className="h-12 w-auto mb-4 cursor-pointer hover:scale-105 transition-transform filter brightness-0 invert"
              onClick={() => setActiveSection("home")}
            />
            <p className="text-slate-300 mb-4">Your trusted partner for home loans</p>
            <p className="text-teal-400 font-medium italic">"Sapne kiraye pe nahi rehte"</p>
          </div>
          <div>
            <h4 className="font-bold text-teal-400 mb-6 text-lg">Quick Links</h4>
            <ul className="space-y-3">
              {["Home", "EMI Calculator", "Apply Now", "Track Loan", "About Us"].map((link) => (
                <li key={link}>
                  <a href="#" className="text-slate-300 hover:text-teal-400 transition-colors hover:underline">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-teal-400 mb-6 text-lg">Services</h4>
            <ul className="space-y-3 text-slate-300">
              <li>Home Loans</li>
              <li>Loan Against Property</li>
              <li>Balance Transfer</li>
              <li>Top-up Loans</li>
              <li>Construction Loans</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-teal-400 mb-6 text-lg">Contact Info</h4>
            <div className="space-y-4 text-slate-300">
              <p className="flex items-center hover:text-teal-400 transition-colors">
                <Phone size={18} className="mr-3" /> 1800-123-4567
              </p>
              <p className="flex items-center hover:text-teal-400 transition-colors">
                <Mail size={18} className="mr-3" /> info@jstbank.com
              </p>
              <p className="flex items-center hover:text-teal-400 transition-colors">
                <MapPin size={18} className="mr-3" /> Mumbai, India
              </p>
            </div>
          </div>
        </div>
        <div className="border-t border-slate-700 pt-8 text-center text-slate-400">
          <p>&copy; 2024 JST Bank. All rights reserved. | Privacy Policy | Terms & Conditions</p>
        </div>
      </div>
    </footer>
  )

  if (!isLoggedIn) {
    return <LoginSignupPage />
  }

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900">
      <Navigation />

      {activeSection === "home" && (
        <>
          <HeroSection />
          <FeaturesSection />
        </>
      )}

      {activeSection === "calculator" && <CalculatorSection />}
      {activeSection === "application" && <ApplicationSection />}
      {activeSection === "tracker" && <TrackerSection />}
      {activeSection === "about" && <AboutSection />}

      <Footer />
    </div>
  )
}
