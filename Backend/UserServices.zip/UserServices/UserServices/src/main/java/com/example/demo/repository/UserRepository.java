package com.example.demo.repository;

import com.example.demo.entity.User;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface UserRepository extends JpaRepository<User, String> {

	@Query(value = "SELECT user_id FROM (SELECT user_id FROM users ORDER BY user_id DESC) WHERE ROWNUM = 1", nativeQuery = true)
	String findLastUserId();
	
	Optional<User> findByEmailAndPassword(String email, String password);
	//User findByEmailAndPassword(String email, String password);



}
