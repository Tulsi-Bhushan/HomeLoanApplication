package com.example.demo.service;

import com.example.demo.DTO.LoginRequest;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    public Map<String, Object> login(LoginRequest loginRequest) {
        Optional<User> userOpt = userRepository.findByEmailAndPassword(
                loginRequest.getEmail(), loginRequest.getPassword());

        Map<String, Object> response = new HashMap<>();

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            response.put("success", true);
            response.put("message", "Login successful");
            response.put("user", user);
        } else {
            response.put("success", false);
            response.put("message", "Invalid email or password");
        }
        
        return response;
    }
   
    
    public Map<String, Object> adminLogin(LoginRequest loginRequest) {
        Optional<User> userOpt = userRepository.findByEmailAndPassword(
                loginRequest.getEmail(), loginRequest.getPassword());

        Map<String, Object> response = new HashMap<>();

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if ("Admin".equalsIgnoreCase(user.getRole())) {
                response.put("success", true);
                response.put("message", "Admin login successful");
                response.put("firstName", user.getFirstName());
                response.put("lastName", user.getLastName());
                response.put("email", user.getEmail());
                response.put("role", user.getRole());
            } else {
                response.put("success", false);
                response.put("message", "Invalid credentials: Customer access denied");
            }
        } else {
            response.put("success", false);
            response.put("message", "Invalid credentials: User not found");
        }
        
        return response;
    }
    
    
  

}
