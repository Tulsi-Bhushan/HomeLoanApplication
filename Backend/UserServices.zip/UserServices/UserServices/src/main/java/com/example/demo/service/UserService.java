package com.example.demo.service;

import com.example.demo.DTO.SignupRequest;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User createUserFromSignup(SignupRequest request) {
        String lastId = userRepository.findLastUserId();
        int newId = 100;

        if (lastId != null && lastId.startsWith("U")) {
            newId = Integer.parseInt(lastId.substring(1)) + 1;
        }

        User user = new User();
        user.setUserId("U" + newId);
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
        user.setPassword(request.getPassword());
        user.setPhone(request.getPhone());
        user.setRole("Customer");

        return userRepository.save(user);
    }

    
    
}


