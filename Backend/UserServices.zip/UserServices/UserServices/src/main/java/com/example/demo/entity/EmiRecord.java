package com.example.demo.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "EMI_Calculations")
public class EmiRecord {
    
    @Id
    @Column(name = "APP_ID", length = 20)
    private String appId;
    
    @Column(name = "LOAN_AMOUNT", precision = 15, scale = 2, nullable = false)
    private BigDecimal loanAmount;
    
    @Column(name = "TENURE", nullable = false)
    private Integer tenure;
    
    @Column(name = "INTEREST_RATE", precision = 5, scale = 2, nullable = false)
    private BigDecimal interestRate;
    
    @Column(name = "EMI_AMOUNT", precision = 15, scale = 2, nullable = false)
    private BigDecimal emiAmount;
    
    // Default constructor
    public EmiRecord() {}
    
    // Constructor with all fields
    public EmiRecord(String appId, BigDecimal loanAmount, Integer tenure, 
                    BigDecimal interestRate, BigDecimal emiAmount) {
        this.appId = appId;
        this.loanAmount = loanAmount;
        this.tenure = tenure;
        this.interestRate = interestRate;
        this.emiAmount = emiAmount;
    }
    
    // Getters and Setters
    public String getAppId() {
        return appId;
    }
    
    public void setAppId(String appId) {
        this.appId = appId;
    }
    
    public BigDecimal getLoanAmount() {
        return loanAmount;
    }
    
    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }
    
    public Integer getTenure() {
        return tenure;
    }
    
    public void setTenure(Integer tenure) {
        this.tenure = tenure;
    }
    
    public BigDecimal getInterestRate() {
        return interestRate;
    }
    
    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }
    
    public BigDecimal getEmiAmount() {
        return emiAmount;
    }
    
    public void setEmiAmount(BigDecimal emiAmount) {
        this.emiAmount = emiAmount;
    }
    
    @Override
    public String toString() {
        return "EmiRecord{" +
                "appId='" + appId + '\'' +
                ", loanAmount=" + loanAmount +
                ", tenure=" + tenure +
                ", interestRate=" + interestRate +
                ", emiAmount=" + emiAmount +
                '}';
    }
}
