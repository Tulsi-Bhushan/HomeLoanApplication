package com.example.demo.service;

import com.example.demo.dto.LoanTrackerDTO;
import com.example.demo.repository.LoanTrackerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanTrackerService {

    private final LoanTrackerRepository repository;

    public LoanTrackerService(LoanTrackerRepository repository) {
        this.repository = repository;
    }

    public List<LoanTrackerDTO> getStatusHistory(String appId) {
        return repository.findStatusHistoryByAppId(appId);
    }
}
