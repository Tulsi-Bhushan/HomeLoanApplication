package com.example.demo.repository;

import com.example.demo.dto.LoanTrackerDTO;
import com.example.demo.entity.LoanTracker;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LoanTrackerRepository extends CrudRepository<LoanTracker, String> {

    @Query(value = """
        SELECT DISTINCT new com.example.demo.dto.LoanTrackerDTO(l.appId, l.statusUpdate, l.dateApp)
        FROM LoanTracker l
        WHERE l.appId = :appId
        ORDER BY l.dateApp
    """)
    List<LoanTrackerDTO> findStatusHistoryByAppId(@Param("appId") String appId);
}
