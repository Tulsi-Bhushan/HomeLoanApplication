package com.example.demo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class LoanTrackerServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(LoanTrackerServiceApplication.class, args);
        System.out.println("loan tracker service started");
    }
}
