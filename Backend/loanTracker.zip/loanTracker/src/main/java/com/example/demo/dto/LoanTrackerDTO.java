package com.example.demo.dto;

import java.util.Date;

public class LoanTrackerDTO {
    private String appId;
    private String statusUpdate;
    private Date dateApp;

    public LoanTrackerDTO(String appId, String statusUpdate, Date dateApp) {
        this.appId = appId;
        this.statusUpdate = statusUpdate;
        this.dateApp = dateApp;
    }

    // Getters
    public String getAppId() { return appId; }
    public String getStatusUpdate() { return statusUpdate; }
    public Date getDateApp() { return dateApp; }

    // Setters
    public void setAppId(String appId) { this.appId = appId; }
    public void setStatusUpdate(String statusUpdate) { this.statusUpdate = statusUpdate; }
    public void setDateApp(Date dateApp) { this.dateApp = dateApp; }
}
