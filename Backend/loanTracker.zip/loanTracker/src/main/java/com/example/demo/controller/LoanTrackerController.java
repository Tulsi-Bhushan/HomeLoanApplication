package com.example.demo.controller;

import com.example.demo.dto.LoanTrackerDTO;
import com.example.demo.service.LoanTrackerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") // Or specify frontend origin explicitly
public class LoanTrackerController {

    private final LoanTrackerService service;

    public LoanTrackerController(LoanTrackerService service) {
        this.service = service;
    }

    @GetMapping("/status-history/{appId}")
    public List<LoanTrackerDTO> getStatusHistory(@PathVariable String appId) {
        return service.getStatusHistory(appId);
    }
}
