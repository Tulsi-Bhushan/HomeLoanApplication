package com.example.demo.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "loan_tracker")
public class LoanTracker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "app_id")
    private String appId;

    @Column(name = "status_update")
    private String statusUpdate;

    @Column(name = "date_app")
    @Temporal(TemporalType.DATE)
    private Date dateApp;

    // Getters and Setters

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getAppId() { return appId; }

    public void setAppId(String appId) { this.appId = appId; }

    public String getStatusUpdate() { return statusUpdate; }

    public void setStatusUpdate(String statusUpdate) { this.statusUpdate = statusUpdate; }

    public Date getDateApp() { return dateApp; }

    public void setDateApp(Date dateApp) { this.dateApp = dateApp; }
}
