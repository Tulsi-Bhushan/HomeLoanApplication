package com.table.loan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanApplicationFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
