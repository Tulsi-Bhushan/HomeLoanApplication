package com.table.loan.dto;

public class LoanApplicationDTO {
    private String appId;  // Existing from IncomeDetails
    private double loanAmount;
    private int tenure;
    private String userId;

    // Getters and Setters
    public String getAppId() { return appId; }
    public void setAppId(String appId) { this.appId = appId; }

    public double getLoanAmount() { return loanAmount; }
    public void setLoanAmount(double loanAmount) { this.loanAmount = loanAmount; }

    public int getTenure() { return tenure; }
    public void setTenure(int tenure) { this.tenure = tenure; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
}
