package com.table.loan.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "LOAN_PROPERTY")
public class LoanProperty {

    @Id
    @Column(name = "APP_ID")
    private String appId;

    @Column(name = "LOAN_AMOUNT")
    private double loanAmount;

    @Column(name = "TENURE")
    private int tenure;

    @Column(name = "INTEREST_RATE")
    private double interestRate;

    @Column(name = "PROPERTY_LOCATION")
    private String propertyLocation;

    @Column(name = "PROPERTY_NAME")
    private String propertyName;

    @Column(name = "PROPERTY_COST")
    private double propertyCost;

    // Getters and Setters
    public String getAppId() { return appId; }
    public void setAppId(String appId) { this.appId = appId; }

    public double getLoanAmount() { return loanAmount; }
    public void setLoanAmount(double loanAmount) { this.loanAmount = loanAmount; }

    public int getTenure() { return tenure; }
    public void setTenure(int tenure) { this.tenure = tenure; }

    public double getInterestRate() { return interestRate; }
    public void setInterestRate(double interestRate) { this.interestRate = interestRate; }

    public String getPropertyLocation() { return propertyLocation; }
    public void setPropertyLocation(String propertyLocation) { this.propertyLocation = propertyLocation; }

    public String getPropertyName() { return propertyName; }
    public void setPropertyName(String propertyName) { this.propertyName = propertyName; }

    public double getPropertyCost() { return propertyCost; }
    public void setPropertyCost(double propertyCost) { this.propertyCost = propertyCost; }
}
