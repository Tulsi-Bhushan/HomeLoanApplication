package com.table.loan.service;

import org.springframework.web.multipart.MultipartFile;

import com.table.loan.dto.DocumentUploadDTO;
import com.table.loan.entity.DocumentUpload;

import java.util.List;

public interface DocumentUploadService {
 DocumentUpload save(DocumentUpload documentUpload);
 List<DocumentUpload> getDocumentsByAppId(String appId);
 void deleteById(String docId);
 List<DocumentUpload> getAll();
 void saveDocument(DocumentUploadDTO dto);


}
