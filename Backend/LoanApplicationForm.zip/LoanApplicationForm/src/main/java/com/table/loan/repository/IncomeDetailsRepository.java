package com.table.loan.repository;

import com.table.loan.entity.IncomeDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
public interface IncomeDetailsRepository extends JpaRepository<IncomeDetails, String> {
    IncomeDetails findTopByOrderByAppIdDesc(); 
  

    // ✅ Custom query to get max APP_ID
    @Query("SELECT MAX(i.appId) FROM IncomeDetails i")
    String findMaxAppId();// ✅ This method must exist

}


