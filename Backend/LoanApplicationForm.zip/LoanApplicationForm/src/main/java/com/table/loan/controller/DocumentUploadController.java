package com.table.loan.controller;

import com.table.loan.dto.DocumentUploadDTO;
import com.table.loan.entity.LoanTracker;
import com.table.loan.repository.IncomeDetailsRepository;
import com.table.loan.repository.LoanTrackerRepository;
import com.table.loan.service.DocumentUploadService;
import com.table.loan.service.LoanTrackerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;  // ✅ MISSING IMPORT FIXED

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/documents")
public class DocumentUploadController {

    @Autowired
    private DocumentUploadService documentUploadService;

    @Autowired
    private IncomeDetailsRepository incomeDetailsRepository;

    @Autowired
    private LoanTrackerRepository loanTrackerRepository;
    
    @Autowired
    private LoanTrackerService loanTrackerService;


//    @PostMapping("/upload")
//    public ResponseEntity<String> uploadDocuments(@RequestBody List<DocumentUploadDTO> documents) {
//        try {
//            for (DocumentUploadDTO dto : documents) {
//                documentUploadService.saveDocument(dto);
//
//                // Also update loan_tracker table
//                LoanTracker tracker = new LoanTracker();
//                tracker.setAppId(dto.getAppId());
//                tracker.setStatusUpdate("Documents Uploaded");
//                tracker.setDateApp(LocalDate.now());
//
//                if (!incomeDetailsRepository.existsById(dto.getAppId())) {
//                    throw new RuntimeException("APP_ID " + dto.getAppId()+ " does not exist.");
//                }
//                loanTrackerRepository.save(tracker);
//
//            }
//
//            return ResponseEntity.ok("Documents uploaded and tracker updated");
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                                 .body("Error uploading documents: " + e.getMessage());
//        }
//    }
// 
    @PostMapping("/upload")
    public ResponseEntity<String> uploadDocuments(@RequestBody List<DocumentUploadDTO> documents) {
        try {
            for (DocumentUploadDTO dto : documents) {
                documentUploadService.saveDocument(dto);

                // Also update loan_tracker table
                LoanTracker tracker = new LoanTracker();
                tracker.setAppId(dto.getAppId());
                tracker.setStatusUpdate("Documents Uploaded");
                tracker.setDateApp(Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()));

                if (!incomeDetailsRepository.existsById(dto.getAppId())) {
                    throw new RuntimeException("APP_ID " + dto.getAppId() + " does not exist.");
                }
                loanTrackerRepository.save(tracker);
            }

            return ResponseEntity.ok("Documents uploaded and tracker updated");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Error uploading documents: " + e.getMessage());
        }
    }

}
