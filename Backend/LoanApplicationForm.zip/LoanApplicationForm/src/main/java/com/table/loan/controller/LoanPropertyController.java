package com.table.loan.controller;

import com.table.loan.entity.LoanProperty;
import com.table.loan.service.LoanPropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/loan-property")
@CrossOrigin("*")
public class LoanPropertyController {

    @Autowired
    private LoanPropertyService service;

    @PostMapping("/save")
    public LoanProperty saveOrUpdate(@RequestBody LoanProperty loanProperty) {
        return service.saveOrUpdate(loanProperty);
    }

    @GetMapping("/{appId}")
    public LoanProperty getByAppId(@PathVariable String appId) {
        return service.getByAppId(appId);
    }

    @GetMapping("/all")
    public List<LoanProperty> getAll() {
        return service.getAll();
    }

    @DeleteMapping("/delete/{appId}")
    public String delete(@PathVariable String appId) {
        service.deleteByAppId(appId);
        return "Deleted App ID: " + appId;
    }
}
