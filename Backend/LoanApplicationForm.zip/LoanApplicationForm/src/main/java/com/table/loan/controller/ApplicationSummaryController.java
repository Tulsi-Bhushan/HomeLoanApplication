package com.table.loan.controller;

import com.table.loan.service.ApplicationSummaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/documents")
@CrossOrigin(origins = "*") // Allow all frontend domains
public class ApplicationSummaryController {

    @Autowired
    private ApplicationSummaryService summaryService;

    @GetMapping("/download-summary/{appId}")
    public ResponseEntity<Resource> downloadApplicationSummary(@PathVariable String appId) {
        return summaryService.generateApplicationSummary(appId);
    }
}
