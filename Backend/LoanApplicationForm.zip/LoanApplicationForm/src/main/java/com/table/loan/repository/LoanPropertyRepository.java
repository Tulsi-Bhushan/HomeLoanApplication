package com.table.loan.repository;

import com.table.loan.entity.LoanProperty;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanPropertyRepository extends JpaRepository<LoanProperty, String> {
}
