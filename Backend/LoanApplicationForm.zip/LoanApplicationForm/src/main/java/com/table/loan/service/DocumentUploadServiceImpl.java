package com.table.loan.service;

import com.table.loan.dto.DocumentUploadDTO;
import com.table.loan.entity.DocumentUpload;
import com.table.loan.repository.DocumentUploadRepository;
import com.table.loan.service.DocumentUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;

@Service
public class DocumentUploadServiceImpl implements DocumentUploadService {

 private final DocumentUploadRepository drepository;

 public DocumentUploadServiceImpl(DocumentUploadRepository repository) {
     this.drepository = repository;
 }

 @Override
 public DocumentUpload save(DocumentUpload documentUpload) {
     return drepository.save(documentUpload);
 }

 @Override
 public List<DocumentUpload> getDocumentsByAppId(String appId) {
     return drepository.findByAppId(appId);
 }

 @Override
 public void deleteById(String docId) {
     drepository.deleteById(docId);
 }

 @Override
 public List<DocumentUpload> getAll() {
     return drepository.findAll();
 }

 @Override
 public void saveDocument(DocumentUploadDTO dto) {
     DocumentUpload entity = new DocumentUpload();
     entity.setDocId(UUID.randomUUID().toString());
     entity.setAppId(dto.getAppId());
     entity.setDocumentType(dto.getDocumentType());
     entity.setFileName(dto.getFileName());
     drepository.save(entity);
 }
}
