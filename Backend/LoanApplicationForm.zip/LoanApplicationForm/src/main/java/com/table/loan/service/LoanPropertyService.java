package com.table.loan.service;

import com.table.loan.entity.LoanProperty;
import java.util.List;

public interface LoanPropertyService {
    LoanProperty saveOrUpdate(LoanProperty loanProperty);
    LoanProperty getByAppId(String appId);
    List<LoanProperty> getAll();
    void deleteByAppId(String appId);
}
