package com.table.loan.service;


import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

public interface ApplicationSummaryService {
    ResponseEntity<Resource> generateApplicationSummary(String appId);
}
