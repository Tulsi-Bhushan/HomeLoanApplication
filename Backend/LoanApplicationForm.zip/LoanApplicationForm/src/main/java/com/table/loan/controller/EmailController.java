package com.table.loan.controller;

//Java Program to Create Rest Controller that

//Importing required classes
import com.table.loan.entity.EmailDetails;
import com.table.loan.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;
//Annotation
@RestController
@CrossOrigin(origins = "*")
//Class
public class EmailController {

// @Autowired private EmailService emailService;

 // Sending a simple Email
// @PostMapping("/sendMail")
// public String
// sendMail(@RequestBody EmailDetails details)
// {
//     String status
//         = emailService.sendSimpleMail(details);
//
//     return status;
// }
//
// // Sending email with attachment
// @PostMapping("/sendMailWithAttachment")
// public String sendMailWithAttachment(
//     @RequestBody EmailDetails details)
// {
//     String status
//         = emailService.sendMailWithAttachment(details);
//
//     return status;
// }
//}
	@Autowired private EmailService emailService;

    @PostMapping("/sendMail")
    public ResponseEntity<String> sendMail(@RequestBody EmailDetails details) {
        String result = emailService.sendSimpleMail(details);
        if (result.equalsIgnoreCase("Mail Sent Successfully...")) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(500).body(result);
        }
    }

    @PostMapping("/sendMailWithAttachment")
    public ResponseEntity<String> sendMailWithAttachment(@RequestBody EmailDetails details) {
        String result = emailService.sendMailWithAttachment(details);
        if (result.equalsIgnoreCase("Mail Sent Successfully...")) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(500).body(result);
        }
    }
 }
