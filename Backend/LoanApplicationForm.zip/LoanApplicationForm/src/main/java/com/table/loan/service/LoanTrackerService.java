
package com.table.loan.service;

import java.util.List;

import com.table.loan.entity.LoanTracker;

public interface LoanTrackerService {
    LoanTracker save(LoanTracker tracker);
    List<LoanTracker> getAll();
}
