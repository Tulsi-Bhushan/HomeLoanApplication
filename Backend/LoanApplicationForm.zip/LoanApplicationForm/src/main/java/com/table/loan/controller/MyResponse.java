package com.table.loan.controller;

public class MyResponse {

    private String message;
    private boolean success;
    private Object data;

    public MyResponse() {}
    
    public MyResponse(String message, boolean status) {
        this.message = message;
        this.success = status;
    }
    public MyResponse(String message, boolean success, Object data) {
        this.message = message;
        this.success = success;
        this.data = data;
    }

    // Getter and Setter
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }
    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Object getData() {
        return data;
    }
    public void setData(Object data) {
        this.data = data;
    }
}
