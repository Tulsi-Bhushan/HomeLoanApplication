package com.table.loan.service;


import com.table.loan.entity.PersonalDetails;
import java.util.List;

public interface PersonalDetailsService {
    PersonalDetails saveDetails(PersonalDetails details);
    List<PersonalDetails> getAll();
    PersonalDetails getByAppId(String appId);
    PersonalDetails updateDetails(String appId, PersonalDetails details);
    void deleteByAppId(String appId);
}
