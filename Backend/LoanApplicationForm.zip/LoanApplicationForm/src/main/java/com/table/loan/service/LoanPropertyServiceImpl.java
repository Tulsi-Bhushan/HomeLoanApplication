package com.table.loan.service;

import com.table.loan.entity.LoanProperty;
import com.table.loan.repository.LoanPropertyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoanPropertyServiceImpl implements LoanPropertyService {

    @Autowired
    private LoanPropertyRepository repo;

    @Override
    public LoanProperty saveOrUpdate(LoanProperty loanProperty) {
        loanProperty.setInterestRate(8.5); // Fixed interest rate
        return repo.save(loanProperty);
    }

    @Override
    public LoanProperty getByAppId(String appId) {
        return repo.findById(appId)
                .orElseThrow(() -> new RuntimeException("Loan property not found for App ID: " + appId));
    }

    @Override
    public List<LoanProperty> getAll() {
        return repo.findAll();
    }

    @Override
    public void deleteByAppId(String appId) {
        repo.deleteById(appId);
    }
}
