package com.table.loan.controller;

import com.table.loan.entity.LoanTracker;
import com.table.loan.service.LoanTrackerService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/tracker")
@CrossOrigin(origins = "*")  // allow calls from frontend
public class LoanTrackerController {

    @Autowired
    private LoanTrackerService loanTrackerService;
   

 
    @PostMapping(value = "/update", consumes = "application/json")
    public ResponseEntity<String> updateTracker(@RequestBody LoanTracker tracker){

       try {
           loanTrackerService.save(tracker);
           return ResponseEntity.ok("Loan tracker updated successfully.");
      } catch (Exception e) {
          e.printStackTrace();
            return ResponseEntity.status(500).body("Failed to update loan tracker.");
       }
   }
    @GetMapping("/all")
    public ResponseEntity<List<LoanTracker>> getAllTrackers() {
        List<LoanTracker> trackers = loanTrackerService.getAll();
        return ResponseEntity.ok(trackers);
    }

}
