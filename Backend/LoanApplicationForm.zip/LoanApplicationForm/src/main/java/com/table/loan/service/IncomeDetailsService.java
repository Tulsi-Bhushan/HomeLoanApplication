package com.table.loan.service;

import com.table.loan.entity.IncomeDetails;
import java.util.List;

public interface IncomeDetailsService {

    IncomeDetails saveOrUpdateIncomeDetails(IncomeDetails details); // Create

    IncomeDetails getIncomeDetailsByAppId(String appId); // Read one

    List<IncomeDetails> getAllIncomeDetails(); // Read all

    IncomeDetails updateIncomeDetails(IncomeDetails incomeDetails); // Update

    void deleteIncomeDetails(String appId); // Delete
}
