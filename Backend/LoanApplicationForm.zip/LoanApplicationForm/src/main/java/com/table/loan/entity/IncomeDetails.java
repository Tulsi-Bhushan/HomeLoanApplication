package com.table.loan.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "INCOME_DETAILS")
public class IncomeDetails {

	@Id
	@Column(name = "APP_ID")
	private String appId;


    @Column(name = "MONTHLY_INCOME")
    private double monthlyIncome;

    @Column(name = "EMPLOYER_NAME")
    private String employerName;

    @Column(name = "EMPLOYMENT_TYPE")
    private String employmentType;

    @Column(name = "RETIREMENT_AGE")
    private int retirementAge;

    // Getters and setters
    public String getAppId() { return appId; }
    public void setAppId(String appId) { this.appId = appId; }

    public double getMonthlyIncome() { return monthlyIncome; }
    public void setMonthlyIncome(double monthlyIncome) { this.monthlyIncome = monthlyIncome; }

    public String getEmployerName() { return employerName; }
    public void setEmployerName(String employerName) { this.employerName = employerName; }

    public String getEmploymentType() { return employmentType; }
    public void setEmploymentType(String employmentType) { this.employmentType = employmentType; }

    public int getRetirementAge() { return retirementAge; }
    public void setRetirementAge(int retirementAge) { this.retirementAge = retirementAge; }
}
