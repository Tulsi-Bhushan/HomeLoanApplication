package com.table.loan.controller;

import com.table.loan.entity.PersonalDetails;
import com.table.loan.service.PersonalDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/personal")
@CrossOrigin(origins = "*")
public class PersonalDetailsController {

    @Autowired
    private PersonalDetailsService service;

    @PostMapping("/add")
    public ResponseEntity<PersonalDetails> add(@RequestBody PersonalDetails details) {
        return ResponseEntity.ok(service.saveDetails(details));
    }

    @GetMapping("/all")
    public ResponseEntity<List<PersonalDetails>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @GetMapping("/{appId}")
    public ResponseEntity<PersonalDetails> getById(@PathVariable String appId) {
        return ResponseEntity.ok(service.getByAppId(appId));
    }

    @PutMapping("/update/{appId}")
    public ResponseEntity<PersonalDetails> update(@PathVariable String appId, @RequestBody PersonalDetails details) {
        return ResponseEntity.ok(service.updateDetails(appId, details));
    }

    @DeleteMapping("/delete/{appId}")
    public ResponseEntity<Void> delete(@PathVariable String appId) {
        service.deleteByAppId(appId);
        return ResponseEntity.ok().build();
    }
}
