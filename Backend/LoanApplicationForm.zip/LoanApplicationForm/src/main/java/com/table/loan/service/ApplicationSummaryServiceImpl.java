package com.table.loan.service;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfWriter;

import com.table.loan.entity.*;
import com.table.loan.repository.*;
import jakarta.ws.rs.core.HttpHeaders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.util.List;

@Service
public class ApplicationSummaryServiceImpl implements ApplicationSummaryService {

    @Autowired
    private IncomeDetailsRepository incomeRepo;

    @Autowired
    private LoanPropertyRepository propertyRepo;

    @Autowired
    private PersonalDetailsRepository personalRepo;

    @Autowired
    private DocumentUploadRepository documentRepo;

    @Override
    public ResponseEntity<Resource> generateApplicationSummary(String appId) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, out);
            document.open();

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
            Font sectionFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);
            Font bodyFont = FontFactory.getFont(FontFactory.HELVETICA, 12);

            document.add(new Paragraph("Home Loan Application Summary", titleFont));
            document.add(new Paragraph("Application ID: " + appId, bodyFont));
            document.add(new Paragraph("Generated on: " + LocalDate.now(), bodyFont));
            document.add(Chunk.NEWLINE);

            // Income Details
            incomeRepo.findById(appId).ifPresentOrElse(income -> {
                try {
                    document.add(new Paragraph("Income Details", sectionFont));
                    document.add(new Paragraph("Monthly Income: " + income.getMonthlyIncome(), bodyFont));
//                    document.add(new Paragraph("Other Income: " + income.getOtherIncome(), bodyFont));
                    document.add(Chunk.NEWLINE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }, () -> {
                try {
                    document.add(new Paragraph("Income Details: Not Found", bodyFont));
                    document.add(Chunk.NEWLINE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            // Property Details
            propertyRepo.findById(appId).ifPresentOrElse(property -> {
                try {
                    document.add(new Paragraph("Property and Loan Details", sectionFont));
                    document.add(new Paragraph("Property Type: " + property.getPropertyName(), bodyFont));
                    document.add(new Paragraph("Location: " + property.getPropertyLocation(), bodyFont));
                    document.add(new Paragraph("Estimated Value: " + property.getPropertyCost(), bodyFont));
                    document.add(new Paragraph("Loan Amount: " + property.getLoanAmount(), bodyFont));
                    document.add(new Paragraph("Tenure: " + property.getTenure(), bodyFont));
                    document.add(new Paragraph("Interest Rate: " + property.getInterestRate(), bodyFont));
                    document.add(Chunk.NEWLINE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }, () -> {
                try {
                    document.add(new Paragraph("Property Details: Not Found", bodyFont));
                    document.add(Chunk.NEWLINE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            // Personal Details
            personalRepo.findById(appId).ifPresentOrElse(personal -> {
                try {
                    document.add(new Paragraph("Personal Details", sectionFont));
                    document.add(new Paragraph("Full Name: " + personal.getFirstName() + " " + personal.getLastName(), bodyFont));
                    document.add(new Paragraph("DOB: " + personal.getDob(), bodyFont));
                    document.add(new Paragraph("Email: " + personal.getEmail(), bodyFont));
                    document.add(Chunk.NEWLINE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }, () -> {
                try {
                    document.add(new Paragraph("Personal Details: Not Found", bodyFont));
                    document.add(Chunk.NEWLINE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            // Uploaded Documents
            List<DocumentUpload> docs = documentRepo.findByAppId(appId);
            document.add(new Paragraph("Uploaded Documents", sectionFont));
            if (!docs.isEmpty()) {
                for (DocumentUpload doc : docs) {
                    document.add(new Paragraph("› " + doc.getDocumentType() + " (" + doc.getFileName() + ")", bodyFont));
                }
            } else {
                document.add(new Paragraph("No documents uploaded.", bodyFont));
            }

            document.close();

            ByteArrayResource resource = new ByteArrayResource(out.toByteArray());

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Application_" + appId + ".pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .contentLength(out.size())
                    .body(resource);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(null);
        }
    }
}
