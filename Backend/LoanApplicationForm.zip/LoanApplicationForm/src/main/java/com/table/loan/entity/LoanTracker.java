package com.table.loan.entity;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name = "loan_tracker")
public class LoanTracker {

    @Id
    @Column(name = "APP_ID", nullable = false)
    private String appId;

    @Column(name = "STATUS_UPDATE")
    private String statusUpdate;


    @Column(name = "DATE_APP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateApp;


    // Getters and Setters
    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getStatusUpdate() {
        return statusUpdate;
    }

    public void setStatusUpdate(String statusUpdate) {
        this.statusUpdate = statusUpdate;
    }

    public Date getDateApp() {
        return dateApp;
    }

//    public void setDateApp(Date dateApp) {
//        this.dateApp = dateApp;  // CORRECTED TO ACCEPT Date
//    }

    public void setDateApp(Date dateApp) {
        this.dateApp = dateApp;
    }

}
