package com.table.loan.entity;
import jakarta.persistence.*;

import java.util.UUID;

@Entity
@Table(name = "document_upload")
public class DocumentUpload {

 @Id
 @Column(name = "DOC_ID", nullable = false, length = 20)
 private String docId;

 @Column(name = "APP_ID", length = 255)
 private String appId;

 @Column(name = "DOCUMENT_TYPE", length = 255)
 private String documentType;

 @Column(name = "FILE_NAME", length = 255)
 private String fileName;

 public DocumentUpload() {
     this.docId = UUID.randomUUID().toString().substring(0, 20);
 }

 // Getters & Setters
 public String getDocId() { return docId; }
 public void setDocId(String docId) { this.docId = docId; }

 public String getAppId() { return appId; }
 public void setAppId(String appId) { this.appId = appId; }

 public String getDocumentType() { return documentType; }
 public void setDocumentType(String documentType) { this.documentType = documentType; }

 public String getFileName() { return fileName; }
 public void setFileName(String fileName) { this.fileName = fileName; }
}
