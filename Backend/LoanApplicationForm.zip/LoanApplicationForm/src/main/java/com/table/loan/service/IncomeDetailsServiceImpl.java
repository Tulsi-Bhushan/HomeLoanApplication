package com.table.loan.service;

import com.table.loan.entity.IncomeDetails;
import com.table.loan.repository.IncomeDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
public class IncomeDetailsServiceImpl implements IncomeDetailsService {

    @Autowired
    private IncomeDetailsRepository incomeRepo;

    @Override
    public IncomeDetails saveOrUpdateIncomeDetails(IncomeDetails details) {
        String appId = details.getAppId();

        // CASE 1: Update - appId is present
        if (appId != null && !appId.trim().isEmpty()) {
            Optional<IncomeDetails> existing = incomeRepo.findById(appId);
            if (existing.isPresent()) {
                IncomeDetails existingDetails = existing.get();
                existingDetails.setMonthlyIncome(details.getMonthlyIncome());
                existingDetails.setEmployerName(details.getEmployerName());
                existingDetails.setEmploymentType(details.getEmploymentType());
                existingDetails.setRetirementAge(details.getRetirementAge());
                return incomeRepo.save(existingDetails);
            } else {
                throw new RuntimeException("Cannot update: IncomeDetails with appId " + appId + " not found");
            }
        }

        // CASE 2: Create - generate new appId
        String currentMaxId = getCurrentMaxAppId();
        String newAppId = generateNextAppId(currentMaxId);
        details.setAppId(newAppId);
        return incomeRepo.save(details);
    }


    private String getCurrentMaxAppId() {
        List<IncomeDetails> allApps = incomeRepo.findAll();
        return allApps.stream()
                .map(IncomeDetails::getAppId)
                .filter(id -> id != null && id.startsWith("A"))
                .max(Comparator.comparingInt(id -> Integer.parseInt(id.substring(1))))
                .orElse("A100");  // Default starting value
    }

    private String generateNextAppId(String currentMaxId) {
        int numeric = Integer.parseInt(currentMaxId.substring(1));
        return "A" + (numeric + 1);
    }

    @Override
    public IncomeDetails getIncomeDetailsByAppId(String appId) {
        return incomeRepo.findById(appId).orElseThrow(() ->
                new RuntimeException("IncomeDetails with appId " + appId + " not found"));
    }

    @Override
    public List<IncomeDetails> getAllIncomeDetails() {
        return incomeRepo.findAll();
    }

    @Override
    public IncomeDetails updateIncomeDetails(IncomeDetails incomeDetails) {
        if (incomeRepo.existsById(incomeDetails.getAppId())) {
            return incomeRepo.save(incomeDetails);
        } else {
            throw new RuntimeException("IncomeDetails with appId " + incomeDetails.getAppId() + " not found");
        }
    }

    @Override
    public void deleteIncomeDetails(String appId) {
        if (incomeRepo.existsById(appId)) {
            incomeRepo.deleteById(appId);
        } else {
            throw new RuntimeException("IncomeDetails with appId " + appId + " not found");
        }
    }
}
