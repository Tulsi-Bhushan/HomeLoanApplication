package com.table.loan.controller;

import com.table.loan.entity.IncomeDetails;
import com.table.loan.service.IncomeDetailsService;
import com.table.loan.controller.MyResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/income")
public class IncomeDetailsController {

    @Autowired
    private IncomeDetailsService incomeService;

    // ✅ Create Income Details
    @PostMapping("/add")
    public ResponseEntity<MyResponse> saveIncome(@RequestBody IncomeDetails incomeDetails) {
        IncomeDetails saved = incomeService.saveOrUpdateIncomeDetails(incomeDetails);
        return ResponseEntity.ok(new MyResponse("Income details saved", true, saved));
    }

    // ✅ Get by AppId
    @GetMapping("/{appId}")
    public ResponseEntity<MyResponse> getIncomeDetails(@PathVariable String appId) {
        IncomeDetails found = incomeService.getIncomeDetailsByAppId(appId);
        return ResponseEntity.ok(new MyResponse("Income details found", true, found));
    }

    // ✅ Get all
    @GetMapping("/all")
    public ResponseEntity<MyResponse> getAllIncomeDetails() {
        List<IncomeDetails> all = incomeService.getAllIncomeDetails();
        return ResponseEntity.ok(new MyResponse("All income details fetched", true, all));
    }

    // ✅ Update
    @PutMapping("/update")
    public ResponseEntity<MyResponse> updateIncomeDetails(@RequestBody IncomeDetails incomeDetails) {
        IncomeDetails updated = incomeService.updateIncomeDetails(incomeDetails);
        return ResponseEntity.ok(new MyResponse("Income details updated", true, updated));
    }

    // ✅ Delete
    @DeleteMapping("/delete/{appId}")
    public ResponseEntity<MyResponse> deleteIncomeDetails(@PathVariable String appId) {
        incomeService.deleteIncomeDetails(appId);
        return ResponseEntity.ok(new MyResponse("Income details deleted", true, null));
    }
}
