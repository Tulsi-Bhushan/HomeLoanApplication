package com.table.loan.service;


import com.table.loan.entity.PersonalDetails;
import com.table.loan.repository.PersonalDetailsRepository;
import com.table.loan.service.PersonalDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PersonalDetailsServiceImpl implements PersonalDetailsService {

    @Autowired
    private PersonalDetailsRepository repository;

    @Override
    public PersonalDetails saveDetails(PersonalDetails details) {
        return repository.save(details);
    }

    @Override
    public List<PersonalDetails> getAll() {
        return repository.findAll();
    }

    @Override
    public PersonalDetails getByAppId(String appId) {
        return repository.findById(appId).orElse(null);
    }

    @Override
    public PersonalDetails updateDetails(String appId, PersonalDetails updated) {
        Optional<PersonalDetails> optional = repository.findById(appId);
        if (optional.isPresent()) {
            PersonalDetails existing = optional.get();
            existing.setFirstName(updated.getFirstName());
            existing.setLastName(updated.getLastName());
            existing.setEmail(updated.getEmail());
            existing.setPhone(updated.getPhone());
            existing.setDob(updated.getDob());
            existing.setGender(updated.getGender());
            existing.setNationality(updated.getNationality());
            existing.setPanNo(updated.getPanNo());
            existing.setAadharNo(updated.getAadharNo());
            return repository.save(existing);
        }
        return null;
    }

    @Override
    public void deleteByAppId(String appId) {
        repository.deleteById(appId);
    }
}
