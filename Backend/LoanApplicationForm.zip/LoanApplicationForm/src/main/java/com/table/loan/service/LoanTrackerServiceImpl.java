package com.table.loan.service;

import com.table.loan.entity.LoanTracker;
import com.table.loan.repository.LoanTrackerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.*;

@Service
public class LoanTrackerServiceImpl implements LoanTrackerService {

    @Autowired
    private LoanTrackerRepository loanTrackerRepository;

    @Override
    public LoanTracker save(LoanTracker tracker) {
        // Convert LocalDate to java.util.Date
    	Date date = new Date(); // this includes current date and time
    	tracker.setDateApp(date);
//        Date date = Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant());
//        tracker.setDateApp(date);  // FIXED: now accepting Date
        return loanTrackerRepository.save(tracker);
    }
    @Override
    public List<LoanTracker> getAll() {
        return loanTrackerRepository.findAll();
    }
}
