package com.table.loan.repository;


import com.table.loan.entity.LoanTracker;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanTrackerRepository extends JpaRepository<LoanTracker, String> { }
